<?php
	class SConfig{
		var $_host_name = "localhost";
		var $_site_name = "Sistem Monitoring Tagihan Air";
		var $_database_name = "montair";
		var $_database_user = "root";
		var $_database_password = "";
		var $_table_prefix = "tb_";
		var $_cms_name = "Monitoring Tagihan Air";
	}
?>