
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Gantimeter_model extends MY_Model {
	protected $_table_name ='tgantimeter';
	protected $_primary_key = 'id_gantimeter';
	protected $_order_by = 'id_gantimeter';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'mrumah';
	protected $_primaryjoin_key = 'no_rumah';
	protected $_tablejoin2_name = 'mcustomer';
	protected $_join2 = "mrumah.id_customer = mcustomer.id_customer";
	protected $_tablejoin3_name = 'm3blok';
	protected $_join3 = "mrumah.id_blok = m3blok.id_blok";

	protected $_column_order = array(null,'tanggal_ganti','no_rumah','nm_customer','no_meterlama','no_meterbaru','keterangan',null);
	protected $_column_search = array('tanggal_ganti','no_rumah','nm_customer','no_meterlama','no_meterbaru','keterangan'); 

	function __construct() {
		parent::__construct();
	}	
		
}