
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Aktivasi_model extends MY_Model {
	protected $_table_name ='mrumah';
	protected $_primary_key = 'no_rumah';
	protected $_order_by = 'tanggal_aktivasi';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'mcustomer';
	protected $_join = "mrumah.id_customer = mcustomer.id_customer";
	protected $_tablejoin2_name = 'm3blok';
	protected $_join2 = "mrumah.id_blok = m3blok.id_blok";
	protected $_tablejoin3_name = 'm2cluster';
	protected $_join3 = "m3blok.id_cluster = m2cluster.id_cluster";
	protected $_column_order = array(null,'no_rumah','tanggal_aktivasi','no_kontrak','no_seriemeteran','nm_customer',null);
	protected $_column_search = array('no_rumah','tanggal_aktivasi','no_kontrak','no_seriemeteran','nm_customer'); 

	function __construct() {
		parent::__construct();
	}	
		
}