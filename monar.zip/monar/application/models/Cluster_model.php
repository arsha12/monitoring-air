<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cluster_model extends MY_Model {
	protected $_table_name = 'm2cluster';
	protected $_primary_key = 'id_cluster';
	protected $_order_by = 'cluster';
	protected $_order_by_type = 'ASC';
	protected $_tablejoin_name = 'm1ipa';
	protected $_primaryjoin_key = 'id_ipa';
	protected $_column_order = array(null,'cluster','ipa','status_ipl',null); 
	protected $_column_search = array('cluster','ipa','status_ipl',); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
		'valid_url_format' => '%s yang Anda masukkan tidak diformat dengan benar.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}