<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Setlain_model extends MY_Model {
	protected $_table_name = 'settinglain';
	protected $_primary_key = 'id_setlain';
	protected $_order_by = 'id_setlain';
	protected $_order_by_type = 'DESC';
	protected $_column_order = array(null,'setlain','harga','tahun','jenis',null); 
	protected $_column_search = array('setlain','harga','tahun','jenis'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}