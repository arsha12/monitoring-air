<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logs_model extends MY_Model {
	protected $_table_name ='logs';
	protected $_primary_key = 'id';
	protected $_order_by = 'id';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'akun';
	protected $_join = "logs.users = akun.id_akun";
	protected $_column_order = array(null,'time',null); 
	protected $_column_search = array('time'); 

	function __construct() {
		parent::__construct();
	}	
		
}