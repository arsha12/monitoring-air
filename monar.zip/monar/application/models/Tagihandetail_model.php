<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tagihandetail_model extends MY_Model {
	protected $_table_name = 'tinvoicedetail';
	protected $_primary_key = 'id_tagihandetail';
	protected $_order_by = 'id_tagihandetail';
	protected $_order_by_type = 'ASC';
	protected $_column_order = array(null,'id_tagihan','pemakaian','harga','nominalpakai',null); 
	protected $_column_search = array('id_tagihan','pemakaian','harga','nominalpakai'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}