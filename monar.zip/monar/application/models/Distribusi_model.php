
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Distribusi_model extends MY_Model {
	protected $_table_name ='ldistribusi';
	protected $_primary_key = 'id_distribusi';
	protected $_order_by = 'id_distribusi';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'm1ipa';
	protected $_primaryjoin_key = 'id_ipa';
	protected $_column_order = array(null,'bulan','ipa','jumlah',null);
	protected $_column_search = array('bulan','ipa','jumlah'); 

	function __construct() {
		parent::__construct();
	}	
		
}