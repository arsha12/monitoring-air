
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Surat_model extends MY_Model {
	protected $_table_name ='tsurat';
	protected $_primary_key = 'id_surat';
	protected $_order_by = 'id_surat';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'mrumah';
	protected $_primaryjoin_key = 'no_rumah';
	protected $_tablejoin2_name = 'mcustomer';
	protected $_join2 = "mrumah.id_customer = mcustomer.id_customer";
	protected $_tablejoin3_name = 'm3blok';
	protected $_join3 = "mrumah.id_blok = m3blok.id_blok";
	protected $_column_order = array(null,'tgl_surat','no_surat','no_rumah','bentuk',null);
	protected $_column_search = array('tgl_surat','no_surat','no_rumah','bentuk'); 

	function __construct() {
		parent::__construct();
	}	
		
}