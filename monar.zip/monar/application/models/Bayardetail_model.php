<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Bayardetail_model extends MY_Model {
	protected $_table_name = 'tbayardetail';
	protected $_primary_key = 'id_bayardetail';
	protected $_order_by = 'id_bayardetail';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'tinvoice';
	protected $_primaryjoin_key = 'id_tagihan';
	protected $_column_order = array(null,'no_tagihan','tagihan','denda','total',null); 
	protected $_column_search = array('no_tagihan','tagihan','denda','total'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}