<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class IPA_model extends MY_Model {
	protected $_table_name = 'm1ipa';
	protected $_primary_key = 'id_ipa';
	protected $_order_by = 'ipa';
	protected $_order_by_type = 'ASC';
	protected $_column_order = array(null,'ipa',null); 
	protected $_column_search = array('ipa'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}