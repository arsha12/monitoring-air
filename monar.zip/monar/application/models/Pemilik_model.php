<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pemilik_model extends MY_Model {
	protected $_table_name = 'mcustomer';
	protected $_primary_key = 'id_customer';
	protected $_order_by = 'id_customer';
	protected $_order_by_type = 'ASC';
	protected $_column_order = array(null,'nm_customer',null); 
	protected $_column_search = array('nm_customer'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}