<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Blok_model extends MY_Model {
	protected $_table_name = 'm3blok';
	protected $_primary_key = 'id_blok';
	protected $_order_by = 'id_blok';
	protected $_order_by_type = 'ASC';
	protected $_tablejoin_name = 'm2cluster';
	protected $_primaryjoin_key = 'id_cluster';
	protected $_column_order = array(null,'blok','cluster',null); 
	protected $_column_search = array('blok','cluster'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
		'valid_url_format' => '%s yang Anda masukkan tidak diformat dengan benar.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}