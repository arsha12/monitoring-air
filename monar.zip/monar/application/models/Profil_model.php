<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profil_model extends MY_Model2 {
	protected $_table_name = 'profil';
	protected $_primary_key = 'id_profil';
	protected $_order_by = 'id_profil';
	protected $_order_by_type = 'DESC';
	protected $_column_order = array(null,'nama','alamat','status','dibaca',null); 
	protected $_column_search = array('nama','alamat','status','dibaca'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}