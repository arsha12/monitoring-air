<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pengguna_model extends MY_Model {
	protected $_table_name = 'akun';
	protected $_primary_key = 'id_akun';
	protected $_order_by = 'id_akun';
	protected $_order_by_type = 'ASC';
	protected $_column_order = array(null,'nama_akun','username','email','handphone','level','aktif',null); 
	protected $_column_search = array('nama_akun','username','email','handphone','level','aktif'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
		'valid_email' => '%s yang Anda masukkan tidak diformat dengan benar.',
		'min_length' => '%s Minimal 6 Karakter',
		'matches' => '%s tidak sama dengan Password',

	);	
	function __construct() {
		parent::__construct();
	}	
		
}