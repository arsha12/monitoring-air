<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends MY_Model {
	protected $_table_name = 'akun';
	protected $_primary_key = 'id_akun';
	protected $_order_by = 'id_akun';

	public $rules = array(
		'username' => array(
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'trim|required|xss_clean'
		), 
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|xss_clean|callback_password_check|required'
		)
	);	

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
	);
}