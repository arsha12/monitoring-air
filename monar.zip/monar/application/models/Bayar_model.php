<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Bayar_model extends MY_Model {
	protected $_table_name = 'tbayar';
	protected $_primary_key = 'id_bayar';
	protected $_order_by = 'no_bayar';
	protected $_order_by_type = 'DESC';
	protected $_column_order = array(null,'no_tagihan','no_rumah','keterangan','bayar',null); 
	protected $_column_search = array('no_tagihan','no_rumah','keterangan','bayar'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}