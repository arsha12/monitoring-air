<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Setperiode_model extends MY_Model {
	protected $_table_name = 'settingperiode';
	protected $_primary_key = 'id_setperiode';
	protected $_order_by = 'id_setperiode';
	protected $_order_by_type = 'DESC';
	protected $_column_order = array(null,'tgl_awal','tgl_akhir','status',null); 
	protected $_column_search = array('tgl_awal','tgl_akhir','status'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}