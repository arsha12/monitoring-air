<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Sethargarumah_model extends MY_Model {
	protected $_table_name = 'settingharga';
	protected $_primary_key = 'id_setharga';
	protected $_order_by = 'id_setharga';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name2 = 'mrumah';
	protected $_join = "settingharga.id_cluster = mrumah.urut";
	protected $_column_order = array(null,'m3','harga','ket','urutan','no_rumah',null); 
	protected $_column_search = array('m3','harga','ket','urutan','no_rumah'); 

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}