<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pendapatan_model extends MY_Model {
	protected $_table_name ='lpendapatan';
	protected $_primary_key = 'id_pendapatan';
	protected $_order_by = 'id_pendapatan';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin2_name = 'm3blok';
	protected $_join2 = "lpendapatan.id_blok = m3blok.id_blok";
	protected $_tablejoin3_name = 'm2cluster';
	protected $_join3 = "m3blok.id_cluster = m2cluster.id_cluster";
	protected $_column_order = array(null,'tgl_tagihan','id_blok','m3','jumlah',null);
	protected $_column_search = array('tgl_tagihan','id_blok','m3','jumlah'); 

	function __construct() {
		parent::__construct();
	}	
		
}