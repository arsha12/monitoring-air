<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tagihan_model extends MY_Model {
	protected $_table_name = 'tinvoice';
	protected $_primary_key = 'id_tagihan';
	protected $_order_by = 'id_tagihan';
	protected $_order_by_type = 'DESC';
	protected $_tablejoin_name = 'mrumah';
	protected $_join = "tinvoice.no_rumah = mrumah.no_rumah";
	protected $_tablejoin2_name = 'mcustomer';
	protected $_join2 = "mrumah.id_customer = mcustomer.id_customer";
	protected $_tablejoin3_name = 'm3blok';
	protected $_join3 = "mrumah.id_blok = m3blok.id_blok";

	protected $_column_order = array(null,'no_tagihan','tinvoice.no_rumah','nm_customer','bulan','total_tagihan',null); 
	protected $_column_search = array('no_tagihan','tinvoice.no_rumah','nm_customer','bulan','total_tagihan'); 
	protected $_where = True;

	public $rulepesan = array(
		'required'  => '%s tidak boleh kosong.',
		'is_unique'  => '%s sudah tersedia.',
	);
	function __construct() {
		parent::__construct();
	}	
		
}