<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function bCrypt($pass,$cost){
      $chars='./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
 
      // Build the beginning of the salt
      $salt=sprintf('$2a$%02d$',$cost);
 
      // Seed the random generator
      mt_srand();
 
      // Generate a random salt
      for($i=0;$i<22;$i++) $salt.=$chars[mt_rand(0,63)];
 
     // return the hash
    return crypt($pass,$salt);
}

function tampil($str){
    return htmlentities($str, ENT_QUOTES, 'UTF-8');
}

function encrypt($string){
    $encrypt = base64_encode(base64_encode(base64_encode(base64_encode("$string"))));
    return $encrypt;
}

function decrypt($string){
    $decrypt=base64_decode(base64_decode(base64_decode(base64_decode("$string"))));
    return $decrypt;
}

function greeting() {
  $welcome_string="Welcome!"; 
  $numeric_date=date("G"); 
  if($numeric_date>=0&&$numeric_date<=11) 
  $welcome_string="Selamat Pagi!"; 
  else if($numeric_date>=12&&$numeric_date<=14) 
  $welcome_string="Selamat Siang!";
  else if($numeric_date>=15&&$numeric_date<=17) 
  $welcome_string="Selamat Sore!"; 
  else if($numeric_date>=18&&$numeric_date<=23) 
  $welcome_string="Selamat Malam!";    
  echo "$welcome_string"; 
}

  function getMonthNames(){
      $namaBulan = array(
          1 => 'Januari',
          2 => 'Februari',
          3 => 'Maret',
          4 => 'April',
          5 => 'Mei',
          6 => 'Juni',
          7 => 'Juli',
          8 => 'Agustus',
          9 => 'September',
          10 => 'Oktober',
          11 => 'November',
          12 => 'Desember');
      return $namaBulan;
  }

  function getNameOfMonth($bln){
      $namaBulan = getMonthNames();
      return $namaBulan[(int)$bln];
  }

  function getIndexOfMonth($bln){
      $namaBulan = getMonthNames();
      $allKeys = array_keys($namaBulan, $bln);
      foreach ($allKeys as $key => $value) { $x=$value; }
      return $x;
  }

  function getMonthNamesChild(){
      $namaBulan = array(
          1 => 'Jan',
          2 => 'Feb',
          3 => 'Mar',
          4 => 'Apr',
          5 => 'Mei',
          6 => 'Jun',
          7 => 'Jul',
          8 => 'Agu',
          9 => 'Sep',
          10 => 'Okt',
          11 => 'Nov',
          12 => 'Des');
      return $namaBulan;
  }

  function getNameOfMonthChild($bln){
      $namaBulan = getMonthNamesChild();
      return $namaBulan[(int)$bln];
  }


  function get3LastYears(){
      $listTahun = array();
      $thnNow = intval(date('Y'));
      for($i=$thnNow-2; $i<=$thnNow; $i++){
          $listTahun[(string)$i] = (string)$i;
      }
      return $listTahun;
  }

  function tgl_indo($tgl){
    $tanggal = substr($tgl,8,2);
    $bulan = getBulan(substr($tgl,5,2), 'c');
    $tahun = substr($tgl,0,4);
    return $tanggal.' '.$bulan.' '.$tahun;     
  } 

  function tgl_indo2($tgl){
    $tanggal = substr($tgl,8,2);
    $bulan = getNameOfMonth(substr($tgl,5,2));
    $tahun = substr($tgl,0,4);
    return $tanggal.' '.$bulan.' '.$tahun;     
  } 

  function tgl_arsip($tgl){
    $bulan = getNameOfMonth(substr($tgl,5,2));
    $tahun = substr($tgl,0,4);
    return $bulan.' '.$tahun;       
  } 
 
  function tgl_distribusi($tgl){
    $bulan = getNameOfMonth(substr($tgl,5,2));
    $tahun = substr($tgl,0,4);
    return $bulan.' '.$tahun;       
  }

function angka($nilai) {
  return str_replace(".","",$nilai);
}

function get_user_info($param=null){
	$_this =& get_instance();
	if($param != null){
		return $_this->session->userdata($param);
	}
	else{
		return $_this->session->userdata;
	}
}

function to_word($number){
    $words = "";
    $arr_number = array("","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan","sepuluh","sebelas");

    if($number<12){
      $words = " ".$arr_number[$number];
    } else if($number<20){
      $words = to_word($number-10)." belas";
    } else if($number<100){
      $words = to_word($number/10)." puluh ".to_word($number%10);
    } else if($number<200){
      $words = "seratus ".to_word($number-100);
    } else if($number<1000){
      $words = to_word($number/100)." ratus ".to_word($number%100);
    } else if($number<2000) {
      $words = "seribu ".to_word($number-1000);
    } else if($number<1000000) {
      $words = to_word($number/1000)." ribu ".to_word($number%1000);
    } else if($number<1000000000) {
      $words = to_word($number/1000000)." juta ".to_word($number%1000000);
    } else {
      $words = "undefined";
    }
    return $words;
  }

  function array_filter_by_value($my_array, $index, $value) { 
      if(is_array($my_array) && count($my_array)>0){ 
          foreach(array_keys($my_array) as $key){ 
              $temp[$key] = $my_array[$key][$index]; 
               
              if ($temp[$key] == $value){ 
                  $new_array[$key] = $my_array[$key]; 
              } 
          } 
        } 
    return $new_array; 
  }
?>