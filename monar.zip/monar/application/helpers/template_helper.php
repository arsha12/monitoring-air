<?php	
	function get_template_directory($path,$dir_file){
		global $SConfig;

		$replace_path = str_replace('\\', '/', $path);
		$get_digit_doc_root = strlen(site_url());
		$full_path = substr($replace_path, $get_digit_doc_root - 1);
		return site_url().$full_path.'/'.$dir_file;
	}

	function get_template($view){
		$_this =& get_instance();
		return $_this->site->view($view);
	}

	function set_url($sub){
		$_this =& get_instance();
		return site_url($sub);
	}

	function is_active_page_print($page,$class){
		$_this =& get_instance();
		if($_this->site->side == 'backend' && $page == $_this->uri->segment(2)){
			return $class;
		}
	}

	function title(){
		$_this =& get_instance();
		global $SConfig;
		$array_backend_page = array(
							'login' => 'Login Sistem',
							'dashboard' => 'Dashboard',
							'ipa' => 'Daftar IPA',
							'cluster' => 'Daftar Cluster',
							'blok' => 'Daftar Blok',
							'pelanggan' => 'Daftar Pelanggan',
							'distribusi' => 'Distribusi Air',
							'gantimeter' => 'Ganti Meteran Air',
							'pemutusan' => 'Pemutusan Meteran Air',
							'pengaturan' => 'Pengaturan',
							'aktivasi' => 'Aktivasi Meteran',
							'tagihan' => 'Tagihan Air',
							'pembayaran' => 'Pembayaran Tagihan',
							'pencatatan' => 'Formulir Pencatatan',
							'laporanpelanggan' => 'Laporan Daftar Pelanggan',
							'laporantagihan' => 'Laporan Tagihan',
							'laporanpembayaran' => 'Laporan Pembayaran',
							'laporantunggakan' => 'Laporan Tunggakan',
							'laporansuratpemberitahuan' => 'Laporan Surat Pemberitahuan',
							'laporangantimeteran' => 'Laporan Ganti Meteran',
							'laporanpemutusanmeteran' => 'Laporan Pemutusan',
							'laporanpendapatandistribusi' => 'Laporan Distribusi dan Pendapatan',
							'profile' => 'Profile Pengguna',
							'pengguna' => 'Daftar Pengguna');
		
		$array_frontend_page = array(
							'beranda' => 'Selamat Datang');

		if($_this->site->side == 'backend' && (array_key_exists($_this->uri->segment(1), $array_backend_page))){
			if(array_key_exists($_this->uri->segment(2), $array_backend_page) ){
				return $array_backend_page[$_this->uri->segment(2)] . ' | ' . $SConfig->_cms_name;	
			}
			else{
				return $array_backend_page[$_this->uri->segment(1)] . ' | ' . $SConfig->_cms_name;	
			}			
		}
		else if($_this->site->side == 'frontend' && (array_key_exists($_this->uri->segment(1), $array_backend_page))){
			if(array_key_exists($_this->uri->segment(2), $array_frontend_page) ){
				return $array_frontend_page[$_this->uri->segment(1)] . ' | ' . $SConfig->_cms_name;	
			}
			else{
				return $SConfig->_cms_name;	
			}			
		}
	}

	function form_dropdown_provinsi(){
		$options = array(
			0	=> 'Pilih Provinsi',
	        11	=> 'Aceh',
	        12	=> 'Sumatera Utara',
	        13	=> 'Sumatera Barat',
	        14	=> 'Riau',
	        15	=> 'Jambi',
	        16 	=> 'Sumatera Selatan',
	        17 	=> 'Bengkulu',
	        18 	=> 'Lampung',
	        19 	=> 'Kepulauan Bangka Belitung',
	        21 	=> 'Kepulauan Riau',
	        31 	=> 'DKI Jakarta',
	        32 	=> 'Jawa Barat',
	        33 	=> 'Jawa Tengah',
	        34 	=> 'DI Yogyakarta',
	        35 	=> 'Jawa Timur',
	        36	=> 'Banten',
	        51	=> 'Bali',
	        52	=> 'Nusa Tenggara Barat',
	        53	=> 'Nusa Tenggara Timur',
	        61	=> 'Kalimantan Barat',
	        62	=> 'Kalimantan Timur',
	        63	=> 'Kalimantan Selatan',
	        64	=> 'Kalimantan Timur',
	        65	=> 'Kalimantan Utara',
	        71	=> 'Sulawesi Utara',
	        72	=> 'Sulawesi Tengah',
	        73	=> 'Sulawesi Selatan',
	        74	=> 'Sulawesi Tenggara',
	        75	=> 'Gorontalo',
	        76	=> 'Sulawesi Barat',
	        81	=> 'Maluku',
	        82	=> 'Maluku Utara',
	        91	=> 'Papua Barat',
	        94	=> 'Papua',
		);
		
		return form_dropdown('provinsi', $options, 0, 'id="provinsi" class="form-control" required');
	}

	function batasakhir(){
		$_this =& get_instance();
	    $_this->load->model(array('Setperiode_model'));
		$record = $_this->Setperiode_model->get_by2(array('status' => "active"), NULL, 1, NULL, TRUE);
		return $record['tgl_akhir'];
	}

	function biaya($tahun, $field = 'harga'){
		$_this =& get_instance();
	    $_this->load->model(array('Setlain_model'));
		$record = $_this->Setlain_model->get2($tahun,TRUE);
		return $record[$field];
	}

	function datarumah($rumah, $field = 'no_rumah'){
		$_this =& get_instance();
	    $_this->load->model(array('Rumah_model'));
		$record = $_this->Rumah_model->get2($rumah,TRUE);
		return $record[$field];
	}

	function laporanpdf($view, $data, $setting = [ 'mode' => 'utf-8', 'format' => 'A4'], $title = 'Laporan', $namafile = 'laporan'){
		$_this =& get_instance();
        $_this->load->library('pdf');
        $mpdf = $_this->pdf->load($setting);
        $data['sign'] = get_user_info('nama');
        $data['laporan'] = $title;
        $_this->site->view($view, $data, true);
        $html = $_this->output->get_output();              
		$stylesheet = file_get_contents(site_url().'assets/logo/laporan2.css');
		$mpdf->WriteHTML($stylesheet,1);
        $mpdf->SetTitle($title);
        $mpdf->SetAuthor("Talang Sari Lestari");
        $mpdf->SetHTMLHeader('
        <table width="100%">
        <tr>
          <td width="15%" rowspan="2" align="center"><img src="'.site_url().'assets/logo/logo.jpg" width="80px" /></td>
          <td width="85%" class="company">PT. TALANG SARI LESTARI</td>
        </tr>
        <tr>
          <td class="address">Jalan Perumahan Talang Sari (Kantor Pemasaran) Blok AA No 15A, Kel. Tanah Merah, Kec. Samarinda Utara, Telpon : 0858 4552 0042</td>
        </tr>
        </table>');

        $mpdf->SetHTMLFooter('<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
        <table width="100%">
            <tr>
                <td width="33%">{DATE j F Y H:i:s}</td>
                <td width="33%" align="center">{PAGENO}/{nbpg}</td>
                <td width="33%" style="text-align: right; ">'.get_site('name').'</td>
            </tr>
        </table>
        </div>');
        //$mpdf->SetProtection(array('copy','print','modify','extract'), '', 'MyPassword');
        /*
        $mpdf->SetWatermarkImage(site_url().'assets/logo/logo.jpg');
        $mpdf->showWatermarkImage = true;
        $mpdf->watermarkImageAlpha = 0.3;
        $mpdf->SetWatermarkText("LUNAS");
        $mpdf->showWatermarkText = true;
        $mpdf->watermark_font = 'DejaVuSansCondensed';
        $mpdf->watermarkTextAlpha = 0.1;*/
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);
        $mpdf->Output($namafile, "I");
        exit;
	}

	function datalogs($tabel, $aksi, $deskripsi, $detail){
		$_this =& get_instance();
	    $_this->load->model(array('Logs_model'));
		date_default_timezone_set('Asia/Kuala_Lumpur');
        $data = array(
            'tanggal' => date('Y-m-d'),
            'time' => date('H:i:s'),
            'tabel' => $tabel,
            'action' => $aksi,
            'users' => get_user_info('ID'),
            'description' => $deskripsi,
            'detail' => $detail,
        );
        $_this->Logs_model->insert($data);
	}

	function datatagihan($id, $field = 'id_tagihan'){ 
		$_this =& get_instance();
	    $_this->load->model(array('Tagihan_model'));
		$record = $_this->Tagihan_model->get2($id,TRUE);
		return $record[$field];
	}

	function datatagihan2($where, $field = 'M3Now'){
		$_this =& get_instance();
	    $_this->load->model(array('Tagihan_model'));
		$record = $_this->Tagihan_model->get_by2($where, NULL, 1, NULL, TRUE);
		return $record[$field];
	}

	function datadistribusi($where, $field = 'jumlah'){
		$_this =& get_instance();
	    $_this->load->model(array('Distribusi_model'));
		$record = $_this->Distribusi_model->get_by2($where, NULL, 1, NULL, TRUE);
		return $record[$field];
	}

	function cekfilter($fill) {
        if (count($fill) > 1) {
            $xfilter = implode(", ", $fill);
        } else if (count($fill) == 1) { 
            $xfilter = $fill[0];            
        } else {
            $xfilter = '';
        }
        return $xfilter;
	}

	function status_bayar($tagihan) {
        if ($tagihan > 0) {
            $stx = "Belum Bayar";
        } else {
            $stx = "Sudah Bayar";
        }
        return $stx;
	}

	function potongan($tagihan, $pulsa) {
        if ($pulsa == 0){ 
                $pot = 0;
        } else {
            if ($tagihan < $pulsa) {
                $pot = $tagihan * 10000;
            } else {
                $pot = $pulsa * 10000;   
            }  
        }
        return $pot;
	}

	function sisa($tagihan, $pulsa) {
        if ($pulsa == 0){ 
                $a = 0;
        } else {
            if ($tagihan < $pulsa) {
				$a= $pulsa - $tagihan;
            } else {
                $a = 0;   
            }  
        }
        return $a;
	}

	function periode($tanggal) {
        $date = date_create($tanggal);
        date_add($date, date_interval_create_from_date_string('-2 months'));
        $bln1 = date_format($date, 'm');
        $thn1 = date_format($date, 'Y');
        $th1 = substr($thn1,2,2);
        $date2 = date_create($tanggal);
        date_add($date2, date_interval_create_from_date_string('-1 months'));
        $bln2 = date_format($date2, 'm');
        $thn2 = date_format($date2, 'Y');
        $th2 = substr($thn2,2,2);
        return "26 ".getNameOfMonthChild($bln1)." ".$th1." - 25 ".getNameOfMonthChild($bln2)." ".$th2;
	}

	function tanggal_pemakaian($tanggal) {
        $date2 = date_create($tanggal);
        date_add($date2, date_interval_create_from_date_string('-1 months'));
        return date(date_format($date2, 'Y')."-".date_format($date2, 'm')."-25");
	}

	function selisih ($tanggal) {
		$date1 = date_create($tanggal);
		$date2 = date_create(date("Y-m-d"));
		$interval = date_diff($date1, $date2);
		return $interval->d;
	}

	function jumlahdenda ($tanggal, $tagihan) {
	$_this =& get_instance();
    $_this->load->model(array('Setlain_model'));
    $n = $_this->Setlain_model->get2("3".substr($tanggal,2,2), TRUE);
    $selisih = selisih($tanggal);
    if ($selisih > 0) {
        if ($n['jenis'] == "Persen") {
          $denda = (int)$tagihan * (int)$n['harga'] / 100;
        } else {
          $denda = $n['harga'];                          
        }
        if ($n['kondisi'] == "Kelipatan") { 
          $kali = ceil($selisih / 28); 
          $denda *= $kali;
        }
     } else {
        $denda = 0;
     }		
     return $denda;
	}

    function curen($price){
      return number_format(@$price,0,".", ".");
    }

    function rupiah($price){
    	return "Rp ".number_format(@$price,0,".", ".");
    }

	function random_string($len = 10) {
	    $word = array_merge(range('a', 'z'), range('A', 'Z'), range(0, 9));
	    shuffle($word);
	    return substr(implode($word), 0, $len);
	}    

    function ceiling($number, $significance = 1){
        return ( is_numeric($number) && is_numeric($significance) ) ? (ceil($number/$significance)*$significance) : false;
    }
?>