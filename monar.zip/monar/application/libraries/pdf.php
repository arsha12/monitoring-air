<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class pdf {
  function __construct(){
    include_once APPPATH.'third_party\vendor\autoload.php'; 
    date_default_timezone_set("Asia/Kuala_Lumpur");
  }
  function load($param=[]){
    return new \Mpdf\Mpdf($param);
  }
}