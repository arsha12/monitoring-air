<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends Backend_Controller {
	public function __construct(){
		parent::__construct();
        $this->load->model(array('Pengguna_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/user_profile', $data);        
    }

    public function ambil_profile() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Pengguna_model->get_by(array('username' => get_user_info('username')), NULL, 1, NULL, TRUE);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function profile_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('email')!=$this->input->post('emailold')) {$er="|is_unique[akun.email]";} else {$er="";}
        $this->_validate($er);
        $data = array('nama_akun'=>$this->input->post('nama_lengkap'),'email'=>$this->input->post('email'),'handphone' => str_replace("_","",$this->input->post('handphone')),'alamat' => $this->input->post('alamat'));
        if($this->input->post('password')!=''){
            $data['password']=bCrypt($this->input->post('password'),12);
        }

        if(!empty($_FILES['foto']['name'])) {
            $upload = $this->_do_upload();
            $usr = $this->Pengguna_model->get($this->input->post('id'));
            if(file_exists('uploads/foto_akun/'.$usr->foto_akun) && $usr->foto_akun) {
                unlink('uploads/foto_akun/'.$usr->foto_akun);
                unlink('uploads/foto_akun/small_'.$usr->foto_akun);
            }
            $data['foto_akun'] = $upload;
            $data['path_foto_akun'] = base_url().'/uploads/foto_akun/'.$upload;
        }
        $this->Pengguna_model->update($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    private function _do_upload() {
        $config['upload_path']          = 'uploads/foto_akun/';
        $config['allowed_types']        = 'gif|jpg|png|JPG|JPEG';
        $config['max_size']             = 3000; //set max size allowed in Kilobyte
        //$config['max_width']            = 1000; // set max width image allowed
        //$config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique nam
        $config['encrypt_name']         = true; //just milisecond timestamp fot unique nam
        $this->load->library('upload', $config);
        if(!$this->upload->do_upload('foto')) {
            $data['inputerror'][] = 'foto';
            $data['error_string'][] = 'Upload error: '.$this->upload->display_errors('',''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $config['image_library'] = 'gd2';
            $config['source_image'] = $this->upload->data('full_path');
            $config['new_image'] = 'uploads/foto_akun/small_'.$this->upload->data('file_name');
            $config['maintain_ratio'] = TRUE;
            $config['width'] = 300;
            $config['height'] = 200;
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
        }
        return $this->upload->data('file_name');
    }

    private function _validate($email) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'password' => array(
                'field' => 'password', 
                'label' => 'Password', 
                'rules' => 'trim|xss_clean|min_length[6]',
            ),
            'repassword' => array(
                'field' => 'repassword', 
                'label' => 'Re-Password', 
                'rules' => 'trim|xss_clean|min_length[6]|matches[password]',
            ),
            'email' => array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|xss_clean|valid_email'.$email,
            ), 
            'nama_lengkap' => array(
                'field' => 'nama_lengkap', 
                'label' => 'Nama Lengkap', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('password'))) {
                $data['inputerror'][] = 'password';
                $data['error_string'][] = form_error('password');
            }
            if(!empty(form_error('repassword'))) {
                $data['inputerror'][] = 'repassword';
                $data['error_string'][] = form_error('repassword');
            }
            if(!empty(form_error('email'))) {
                $data['inputerror'][] = 'email';
                $data['error_string'][] = form_error('email');
            }
            if(!empty(form_error('nama_lengkap'))) {
                $data['inputerror'][] = 'nama_lengkap';
                $data['error_string'][] = form_error('nama_lengkap');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}