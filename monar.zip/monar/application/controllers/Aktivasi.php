<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aktivasi extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Aktivasi_model','Setharga_model','Setlain_model','Setperiode_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('module/aktivasi', $data);
    }

    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_rumah' => $this->Aktivasi_model->get_by(array('status_meter !=' => 'Aktif'), 'urut'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function aktivasi_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = $this->Aktivasi_model->get_by(array("no_rumah" => $id, "status_meter !=" => "Aktif"), NULL, 1, NULL, TRUE);
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function aktivasi_preview($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Aktivasi_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function cetak_aktivasi() { 
        //'format' => [190, 236],
        $id = $this->input->post('id');
        $setting = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $this->load->library('pdf');
        $mpdf = $this->pdf->load($setting);
        $stylesheet = file_get_contents(site_url().'assets/logo/laporan2.css');
        $mpdf->WriteHTML($stylesheet,1);
        $mpdf->SetTitle("Kontrak Berlangganan Air");
        $mpdf->SetAuthor("Talang Sari Lestari");
        $mpdf->SetHTMLHeader('
        <table width="100%">
        <tr>
          <td width="15%" rowspan="2" align="center"><img src="'.site_url().'assets/logo/logo.jpg" width="80px" /></td>
          <td width="85%" class="company">PT. TALANG SARI LESTARI</td>
        </tr>
        <tr>
          <td class="address">Jalan Perumahan Talang Sari (Kantor Pemasaran) Blok AA No 15A, Kel. Tanah Merah, Kec. Samarinda Utara, Telpon : 0858 4552 0042</td>
        </tr>
        </table>');
        $pdfFilePath = "cetakkontrak_".time().".pdf";
        $data = array(
            'record_setting' =>  $this->Setperiode_model->get_by2(array('status' => 'Active'), NULL, NULL, NULL, TRUE),
            'administrasi' => biaya("2".date('y')),
            'denda' => $this->Setlain_model->get2("3".date('y')),
            'record_aktivasi' => $this->Aktivasi_model->get2($id)
        );
        $urut = datarumah($id, 'urut');
        $blok = datarumah($id, 'id_blok');
        $cluster = datarumah($id, "id_cluster");
        if ($this->Setharga_model->count(array('id_cluster' => $urut)) > 0) {
          $data['record_harga'] = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $urut),"urutan");
        } else if ($this->Setharga_model->count(array('id_cluster' => $blok)) > 0) {
          $data['record_harga'] = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $blok),"urutan");
        } else {
          $data['record_harga'] = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $cluster),"urutan");
        }
        $this->site->view('laporan/pelanggan/kontrak', $data, true);
        $html = $this->output->get_output();                      
        //$mpdf->SetProtection(array('copy','print','modify','extract'), '', 'MyPassword');
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
        exit;
    }

    public function aktivasi_list() {
       if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Aktivasi_model->get_datatables(array('status_meter' => "Aktif"));
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $rumah) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($rumah->no_rumah).'"> '.$no;
            $row[] = tampil($rumah->no_rumah);
            $row[] = tampil(tgl_indo2($rumah->tanggal_aktivasi));
            $row[] = tampil($rumah->no_kontrak);
            $row[] = tampil($rumah->no_seriemeteran);
            $row[] = tampil($rumah->nm_customer);

            //add html for action
            $row[] = '<a class="btn btn-sm btn-info" href="javascript:void(0)" title="Lihat Aktivasi" onclick="view_data('."'".$rumah->no_rumah."'".')"><i class="glyphicon glyphicon-eye-open"></i></a>
                <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus Aktivasi" onclick="delete_data('."'".$rumah->no_rumah."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
    
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Aktivasi_model->count_all(array('status_meter' => "Aktif")),
            "recordsFiltered" => $this->Aktivasi_model->count_filtered(array('status_meter' => "Aktif")),
            "data" => $data,
        );
        echo json_encode($output);
       } else {
           redirect(set_url('dashboard'));
       }
    }

    public function aktivasi_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate();
        $data = array(
                'no_kontrak' => $this->input->post('nokontrak'),
                'tanggal_aktivasi' => date("Y-m-d H:i:s"),
                'status_meter' => "Aktif",
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Aktivasi_model->update($data,$this->input->post('norumah'));
        datalogs(5, 'Menambahkan Data', 'Data Aktivasi Pelanggan : '.$this->input->post('nokontrak'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function aktivasi_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                    'no_kontrak' => "",
                    'tanggal_aktivasi' => "",
                    'status_meter' => "Non Aktif",
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
            );
            $this->Aktivasi_model->update($data,$id);
            datalogs(5, 'Menghapus Data', 'Menghapus Data Aktivasi : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function aktivasi_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(5, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Aktivasi',json_encode($list_id));
        foreach ($list_id as $id) {
            $data = array(
                    'no_kontrak' => "",
                    'tanggal_aktivasi' => "",
                    'status_meter' => "Non Aktif",
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
            );
            $this->Aktivasi_model->update($data,$id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean',
            ),
            'nokontrak' => array(
                'field' => 'nokontrak', 
                'label' => 'Nomor Kontrak', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }            
            if(!empty(form_error('nokontrak'))) {
                $data['inputerror'][] = 'nokontrak';
                $data['error_string'][] = form_error('nokontrak');
            }            
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }


}