<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Error404 extends Backend_Controller {
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$data = array();
		$this->site->view('module/404', $data);
	}	
}
