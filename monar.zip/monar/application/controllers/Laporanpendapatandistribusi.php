<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporanpendapatandistribusi extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Distribusi_model','Pendapatan_model','Cluster_model','IPA_model'));
        ini_set('max_execution_time', 300);
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporanpendapatandistribusi', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_ipa' => $this->IPA_model->get(NULL, NULL, 'id_ipa'),
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function ipa() { 
        //'format' => [190, 236],
        $tahun = $this->input->post('pendistahun');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'L','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $where = "WHERE year(tb_lpendapatan.tgl_tagihan) = '".$tahun."'";
        $fill[0] ='Tahun '.$tahun;
        $data['filter'] = cekfilter($fill);
        $data['record_ipa'] = $this->IPA_model->get();
        $data['jum_ipa'] = $this->IPA_model->count();
        $data['record_bulan'] = $this->Pendapatan_model->getquery("SELECT DISTINCT tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster ".$where." GROUP BY tb_lpendapatan.tgl_tagihan");
        $data['record_pendapatan'] = $this->Pendapatan_model->getquery2("SELECT tb_lpendapatan.tgl_tagihan, tb_m1ipa.id_ipa, tb_m1ipa.ipa, sum(tb_lpendapatan.m3) as pakai, sum(tb_lpendapatan.jumlah) as jumlah, sum(tb_lpendapatan.bayar) as bayar, sum(tb_lpendapatan.denda) as denda FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster INNER JOIN tb_m1ipa ON tb_m2cluster.id_ipa = tb_m1ipa.id_ipa ".$where." GROUP BY tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa");
        $pdfFilePath = "laporanpendapatandistribusiipa_".time().".pdf";
        laporanpdf('laporan/distribusidanpendapatan/ipa', $data, $set, "Laporan Pendapatan & Distribusi Air", $pdfFilePath);
    }

    public function cluster() { 
        //'format' => [190, 236],
        $tahun = $this->input->post('pendistahun');
        $ipa = $this->input->post('pendisipa');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'L','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $where = "WHERE year(tb_lpendapatan.tgl_tagihan) = '".$tahun."'";
        $where2 = array();
        $xid = '';
        $fill[0] ='Tahun '.$tahun;
        if (!empty($ipa)) {
            $ldata = $this->IPA_model->view($ipa);
            $where .= " AND tb_m2cluster.id_ipa = '".$ipa."'";
            $where2['id_ipa'] = $ipa;
            $xid = $ipa;
            $fill[1] ='IPA '.$ldata->ipa;
        }
        $data['filter'] = cekfilter($fill);
        $data['record_ipa'] = $this->IPA_model->get($xid);
        $data['jum_ipa'] = $this->IPA_model->count($where2);
        $data['record_bulan'] = $this->Pendapatan_model->getquery("SELECT DISTINCT tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster ".$where." GROUP BY tb_lpendapatan.tgl_tagihan");
        $data['record_pendapatan'] = $this->Pendapatan_model->getquery2("SELECT tb_lpendapatan.tgl_tagihan, tb_m1ipa.id_ipa, tb_m1ipa.ipa, tb_m2cluster.cluster, sum(tb_lpendapatan.m3) as pakai, sum(tb_lpendapatan.jumlah) as jumlah, sum(tb_lpendapatan.bayar) as bayar, sum(tb_lpendapatan.denda) as denda FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster INNER JOIN tb_m1ipa ON tb_m2cluster.id_ipa = tb_m1ipa.id_ipa ".$where." GROUP BY tb_lpendapatan.tgl_tagihan, tb_m2cluster.cluster");
        $data['record_pendapatanipa'] = $this->Pendapatan_model->getquery2("SELECT tb_lpendapatan.tgl_tagihan, tb_m1ipa.id_ipa, tb_m1ipa.ipa, sum(tb_lpendapatan.m3) as pakai, sum(tb_lpendapatan.jumlah) as jumlah, sum(tb_lpendapatan.bayar) as bayar, sum(tb_lpendapatan.denda) as denda FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster INNER JOIN tb_m1ipa ON tb_m2cluster.id_ipa = tb_m1ipa.id_ipa ".$where." GROUP BY tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa");
        $pdfFilePath = "laporanpendapatandistribusicluster_".time().".pdf";
        laporanpdf('laporan/distribusidanpendapatan/cluster', $data, $set, "Laporan Pendapatan & Distribusi Air", $pdfFilePath);
    }


    public function pemda() { 
        //'format' => [190, 236],
        $tahun = $this->input->post('pendistahun');
        $ipa = $this->input->post('pendisipa');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $where = "WHERE year(tb_lpendapatan.tgl_tagihan) = '".$tahun."'";
        $where2 = array();
        $xid = '';
        $fill[0] ='Tahun '.$tahun;
        $data['filter'] = cekfilter($fill);
        $data['record_ipa'] = $this->IPA_model->get($xid);
        $data['jum_ipa'] = $this->IPA_model->count();
        $data['record_bulan'] = $this->Pendapatan_model->getquery("SELECT DISTINCT tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster ".$where." GROUP BY tb_lpendapatan.tgl_tagihan");
        $data['record_pendapatan'] = $this->Pendapatan_model->getquery2("SELECT tb_lpendapatan.tgl_tagihan, tb_m1ipa.id_ipa, tb_m1ipa.ipa, tb_m2cluster.cluster, sum(tb_lpendapatan.m3) as pakai, sum(tb_lpendapatan.jumlah) as jumlah, sum(tb_lpendapatan.bayar) as bayar, sum(tb_lpendapatan.denda) as denda FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster INNER JOIN tb_m1ipa ON tb_m2cluster.id_ipa = tb_m1ipa.id_ipa ".$where." GROUP BY tb_lpendapatan.tgl_tagihan, tb_m2cluster.cluster");
        $data['record_pendapatanipa'] = $this->Pendapatan_model->getquery2("SELECT tb_lpendapatan.tgl_tagihan, tb_m1ipa.id_ipa, tb_m1ipa.ipa, sum(tb_lpendapatan.m3) as pakai, sum(tb_lpendapatan.jumlah) as jumlah, sum(tb_lpendapatan.bayar) as bayar, sum(tb_lpendapatan.denda) as denda FROM tb_lpendapatan INNER JOIN tb_m3blok ON tb_lpendapatan.id_blok = tb_m3blok.id_blok INNER JOIN tb_m2cluster ON tb_m3blok.id_cluster = tb_m2cluster.id_cluster INNER JOIN tb_m1ipa ON tb_m2cluster.id_ipa = tb_m1ipa.id_ipa ".$where." GROUP BY tb_lpendapatan.tgl_tagihan, tb_m2cluster.id_ipa");
        $pdfFilePath = "laporanpendapatandistribusipemda_".time().".pdf";
        laporanpdf('laporan/distribusidanpendapatan/pemda', $data, $set, "Laporan Pendapatan & Distribusi Air", $pdfFilePath);
    }

}