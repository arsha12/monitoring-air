<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pelanggan extends Backend_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model(array('Rumah_model','Pemilik_model','Blok_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('module/rumah', $data);
    }

    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
                'record_blok' => $this->Blok_model->get(NULL, NULL, 'id_blok'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = $this->Pemilik_model->get_by(array("no_ktp" => $id), NULL, 1, NULL, TRUE);
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan_cetak() {
        /*
        $pdfFilePath = "output_pdf_name.pdf";
        $data = $this->Rumah_model->get2();
        $this->load->library('m_pdf');
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");    */ 
        $this->load->library('M_pdf');
          $mpdf = $this->m_pdf->load([
           'mode' => 'utf-8',
           'format' => 'A4'
          ]);

          $view = $this->load->view('welcome_message', "", true);

          $mpdf->WriteHTML($view);
          $mpdf->Output();  
    }

    public function pelanggan_preview($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Rumah_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pelanggan_list() {
       if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Rumah_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $rumah) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($rumah->no_rumah).'"> '.$no;
            $row[] = tampil($rumah->no_rumah);
            $row[] = tampil($rumah->type);
            $row[] = tampil($rumah->no_seriemeteran);
            $row[] = tampil($rumah->nm_customer);
            $row[] = $rumah->sisa_pulsa;
            $row[] = tampil($rumah->blok);
            $row[] = tampil($rumah->cluster);
            $row[] = tampil($rumah->status_meter);
            $row[] = tampil($rumah->status_kondisi);

            if ($rumah->status_kondisi == "Kosong") {$b = "success"; $i = "tag";} else {$b = "warning"; $i = "tags";}

            //add html for action
            $row[] = '<a class="btn btn-sm btn-info" href="javascript:void(0)" title="Lihat Pelanggan" onclick="view_data('."'".$rumah->no_rumah."'".')"><i class="glyphicon glyphicon-eye-open"></i></a>
                <a class="btn btn-sm btn-'.$b.'" href="javascript:void(0)" title="Kondisi Rumah" onclick="status_data('."'".$rumah->no_rumah."'".', '."'".$rumah->status_kondisi."'".', '."'kondisi rumah'".')"><i class="glyphicon glyphicon-'.$i.'"></i></a>
                <a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit Pelanggan" onclick="edit_data('."'".$rumah->no_rumah."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus Pelanggan" onclick="delete_data('."'".$rumah->no_rumah."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
    
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Rumah_model->count_all(),
            "recordsFiltered" => $this->Rumah_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
       } else {
           redirect(set_url('dashboard'));
       }
    }

    public function pelanggan_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[mrumah.no_rumah]");
        if ($this->input->post('pemilik') == 'Ada') {
            if (!empty($this->input->post('idpemilik'))) {
                if ($this->input->post('ktp') != $this->input->post('ktpold')) {$kt = "|is_unique[mcustomer.no_ktp]";} else {$kt = "";}
                $this->_validate2($kt);
                $kode2 = $this->input->post('idpemilik');
                $data = array(
                    'no_ktp' => $this->input->post('ktp'),
                    'nm_customer' => $this->input->post('nama'),
                    'no_hp' => $this->input->post('handphone'),
                    'alamat' => $this->input->post('alamatp'),
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
                );
                $this->Pemilik_model->update($data,$kode2);
            } else {
                if ($this->input->post('ktp') != $this->input->post('ktpold')) {$kt = "|is_unique[mcustomer.no_ktp]";} else{$kt = "";}
                $this->_validate2($kt);
                $kode2 = $this->Pemilik_model->kodeauto("PL",7);
                $data = array(
                    'id_customer' => $kode2,
                    'no_ktp' => $this->input->post('ktp'),
                    'nm_customer' => $this->input->post('nama'),
                    'no_hp' => $this->input->post('handphone'),
                    'alamat' => $this->input->post('alamatp'),
                    //'users'=> get_user_info('ID'),
                    //'created'=>date('Y-m-d H:i:s')
                );
                $insert = $this->Pemilik_model->insert($data);
            }
        } else {
            $kode2 = "";
        }
        $tg = '1'.date("ym");
        $x = explode('-',$this->input->post('norumah'));
        $dpn = strlen($x[0]);
        $blk = strlen(intval($x[1]));
        $kd = $dpn.$x[0].$blk.intval($x[1]);
        $f = 7 + $blk;
        $kode = $this->Rumah_model->kodeauto2("urut",$kd,$f);
        $data = array(
                'no_rumah' => $this->input->post('norumah'),
                'type' => $this->input->post('type'),
                'no_seriemeteran' => $this->input->post('meteran'),
                'angka_meteran' => $this->input->post('awal'),
                'id_blok' => $this->input->post('blok'),
                'pulsa_elektrik' => $this->input->post('pulsa'),
                'sisa_pulsa' => $this->input->post('pulsa'),
                'alamat_rumah' => $this->input->post('alamat'),
                'status_bast' => $this->input->post('bast'),
                'urut' => $kode,
                'id_customer'=> $kode2,
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $data['qrcode'] = QrCode($kode);
        $insert = $this->Rumah_model->insert($data);
        datalogs(4, 'Menambahkan Data', 'Data Pelanggan : '.$this->input->post('norumah'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pelanggan_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Rumah_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pelanggan_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("");
        if ($this->input->post('pemilik') == 'Ada') {
            if (!empty($this->input->post('idpemilik'))) {
                if ($this->input->post('ktp') != $this->input->post('ktpold')) {$kt = "|is_unique[mcustomer.no_ktp]";} else{$kt = "";}
                $this->_validate2($kt);
                $kode2 = $this->input->post('idpemilik');
                $data = array(
                    'no_ktp' => $this->input->post('ktp'),
                    'nm_customer' => $this->input->post('nama'),
                    'no_hp' => $this->input->post('handphone'),
                    'alamat' => $this->input->post('alamatp'),
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
                );
                $this->Pemilik_model->update($data,$kode2);
            } else {
                if ($this->input->post('ktp') != $this->input->post('ktpold')) {$kt = "|is_unique[mcustomer.no_ktp]";} else{$kt = "";}
                $this->_validate2($kt);
                $kode2 = $this->Pemilik_model->kodeauto("PL",7);
                $data = array(
                    'id_customer' => $kode2,
                    'no_ktp' => $this->input->post('ktp'),
                    'nm_customer' => $this->input->post('nama'),
                    'no_hp' => $this->input->post('handphone'),
                    'alamat' => $this->input->post('alamatp'),
                    //'users'=> get_user_info('ID'),
                    //'created'=>date('Y-m-d H:i:s')
                );
                $insert = $this->Pemilik_model->insert($data);
            }
        } else {
            $kode2 = "";
        }
        $data = array(
                'type' => $this->input->post('type'),
                'no_seriemeteran' => $this->input->post('meteran'),
                'angka_meteran' => $this->input->post('awal'),
                'id_blok' => $this->input->post('blok'),
                'pulsa_elektrik' => $this->input->post('pulsa'),
                'sisa_pulsa' => $this->input->post('pulsa'),
                'alamat_rumah' => $this->input->post('alamat'),
                'status_bast' => $this->input->post('bast'),
                'id_customer'=> $kode2,
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Rumah_model->update($data,$this->input->post('id'));
        datalogs(4, 'Mengubah Data', 'Data Pelanggan : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pelanggan_status($id, $st) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            if ($st != "Kosong") { $kondisi = "Kosong"; } else { $kondisi = "Berpenghuni"; }
            $data = array(
                    'status_kondisi'=> $kondisi,
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
            );
            $this->Rumah_model->update($data,$id);
            datalogs(4, 'Mengubah Data', 'Kondisi Rumah : '.$kondisi,json_encode($data));
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan_bulk_status($st) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(4, 'Mengubah Data', 'Kondisi Rumah : '.$st.', '.count($list_id).' Pelanggan',json_encode($list_id));
        foreach ($list_id as $id) {
            $data = array(
                    'status_kondisi'=> $st,
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
            );
            $this->Rumah_model->update($data,$id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Rumah_model->delete($id);
            hapusimage($id, 'qcode');
            datalogs(4, 'Menghapus Data', 'Menghapus Data Pelanggan : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(4, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Pelanggan',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Rumah_model->delete($id);
            hapusimage($id, 'qcode');
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($norumah) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean'.$norumah,
            ),
            'type' => array(
                'field' => 'type', 
                'label' => 'Type Rumah', 
                'rules' => 'trim|required|numeric|xss_clean',
            ),
            'blok' => array(
                'field' => 'blok', 
                'label' => 'Blok Perumahan', 
                'rules' => 'trim|required|xss_clean',
            ),
            'meteran' => array(
                'field' => 'meteran', 
                'label' => 'Nomor Serie Meteran', 
                'rules' => 'trim|required|numeric|xss_clean',
            ),
            'awal' => array(
                'field' => 'awal', 
                'label' => 'Angka Awal Meteran', 
                'rules' => 'trim|required|numeric|xss_clean',
            ),
            'pulsa' => array(
                'field' => 'pulsa', 
                'label' => 'Sisa Pulsa Elektrik', 
                'rules' => 'trim|required|numeric|xss_clean',
            ),
            'alamat' => array(
                'field' => 'alamat', 
                'label' => 'Alamat Tinggal', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }            
            if(!empty(form_error('type'))) {
                $data['inputerror'][] = 'type';
                $data['error_string'][] = form_error('type');
            }            
            if(!empty(form_error('blok'))) {
                $data['inputerror'][] = 'blok';
                $data['error_string'][] = form_error('blok');
            }            
            if(!empty(form_error('meteran'))) {
                $data['inputerror'][] = 'meteran';
                $data['error_string'][] = form_error('meteran');
            }
            if(!empty(form_error('awal'))) {
                $data['inputerror'][] = 'awal';
                $data['error_string'][] = form_error('awal');
            }
            if(!empty(form_error('pulsa'))) {
                $data['inputerror'][] = 'pulsa';
                $data['error_string'][] = form_error('pulsa');
            }
            if(!empty(form_error('alamat'))) {
                $data['inputerror'][] = 'alamat';
                $data['error_string'][] = form_error('alamat');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    private function _validate2($ktp) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'ktp' => array(
                'field' => 'ktp',
                'label' => 'Nomor Kartu Tanda Penduduk',
                'rules' => 'trim|required|xss_clean'.$ktp,
            ),
            'nama' => array(
                'field' => 'nama',
                'label' => 'Nama Pemilik',
                'rules' => 'trim|required|xss_clean',
            ),
            'handphone' => array(
                'field' => 'handphone', 
                'label' => 'Nomor Handphone', 
                'rules' => 'trim|xss_clean',
            ),
            'alamatp' => array(
                'field' => 'alamatp', 
                'label' => 'Alamat Pemilik', 
                'rules' => 'trim|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('ktp'))) {
                $data['inputerror'][] = 'ktp';
                $data['error_string'][] = form_error('ktp');
            }            
            if(!empty(form_error('nama'))) {
                $data['inputerror'][] = 'nama';
                $data['error_string'][] = form_error('nama');
            }            
            if(!empty(form_error('handphone'))) {
                $data['inputerror'][] = 'handphone';
                $data['error_string'][] = form_error('handphone');
            }
            if(!empty(form_error('alamatp'))) {
                $data['inputerror'][] = 'alamatp';
                $data['error_string'][] = form_error('alamatp');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}