<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gantimeter extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Gantimeter_model','Rumah_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/gantimeter', $data);
    }
    
   public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_rumah' => $this->Rumah_model->get_by(array('status_meter' => 'Aktif'), 'urut'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }
    
    public function gantimeter_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = $this->Rumah_model->get_by(array("no_rumah" => $id), NULL, 1, NULL, TRUE);
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function gantimeter_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Gantimeter_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $gantimeter) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($gantimeter->id_gantimeter).'"> '.$no;
            $row[] = tampil(tgl_indo2($gantimeter->tanggal_ganti));
            $row[] = tampil($gantimeter->no_rumah);
            $row[] = tampil($gantimeter->nm_customer);
            $row[] = tampil($gantimeter->no_meterlama);
            $row[] = tampil($gantimeter->no_meterbaru);
            $row[] = tampil($gantimeter->keterangan);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" titlindoit" onclick="edit_data('."'".$gantimeter->id_gantimeter."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$gantimeter->id_gantimeter."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Gantimeter_model->count_all(),
                        "recordsFiltered" => $this->Gantimeter_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function gantimeter_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[mrumah.no_seriemeteran]");
        $tg = "G".date("Y");
        $kode = $this->Gantimeter_model->kodeauto($tg,9);
        $data = array(
                'id_gantimeter' => $kode,
                'tanggal_ganti' => date('Y-m-d'),
                'no_rumah' => $this->input->post('norumah'),
                'no_meterbaru' => $this->input->post('meterbaru'),
                'no_meterlama' => $this->input->post('meterlama'),
                'awal' => $this->input->post('awal'),
                'sebelum' => $this->input->post('sebelum'),
                'keterangan' => $this->input->post('keterangan'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Gantimeter_model->insert($data);
        datalogs(6, 'Menambahkan Data', 'Data Ganti Meteran : '.$this->input->post('norumah'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function gantimeter_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Gantimeter_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function gantimeter_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('meterbaru') != $this->input->post('meterbaruold')) {$vd="|is_unique[mrumah.no_seriemeteran]";} else {$vd="";}
        $this->_validate($vd);
        $data = array(
                'no_meterbaru' => $this->input->post('meterbaru'),
                'awal' => $this->input->post('awal'),
                'keterangan' => $this->input->post('keterangan'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Gantimeter_model->update($data,$this->input->post('id'));
        datalogs(6, 'Mengubah Data', 'Data Ganti Meteran : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function gantimeter_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Gantimeter_model->delete($id);
            datalogs(6, 'Menghapus Data', 'Menghapus Data Ganti Meteran : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function gantimeter_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(6, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Ganti Meteran',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Gantimeter_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($Meteran) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean',
            ),
            'meterlama' => array(
                'field' => 'meterlama', 
                'label' => 'Nomor Meteran Lama', 
                'rules' => 'trim|required|xss_clean',
            ),
            'meterbaru' => array(
                'field' => 'meterbaru', 
                'label' => 'Nomor Meteran Baru', 
                'rules' => 'trim|required|xss_clean'.$Meteran,
            ),
            'awal' => array(
                'field' => 'awal', 
                'label' => 'Awal Angka Meteran', 
                'rules' => 'trim|required|xss_clean',
            ),
            'keterangan' => array(
                'field' => 'keterangan', 
                'label' => 'Keterangan Penggatian', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }
            if(!empty(form_error('meterlama'))) {
                $data['inputerror'][] = 'meterlama';
                $data['error_string'][] = form_error('meterlama');
            }
            if(!empty(form_error('meterbaru'))) {
                $data['inputerror'][] = 'meterbaru';
                $data['error_string'][] = form_error('meterbaru');
            }
            if(!empty(form_error('awal'))) {
                $data['inputerror'][] = 'awal';
                $data['error_string'][] = form_error('awal');
            }
            if(!empty(form_error('keterangan'))) {
                $data['inputerror'][] = 'keterangan';
                $data['error_string'][] = form_error('keterangan');
            }

            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}