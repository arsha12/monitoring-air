<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blok extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Cluster_model','Blok_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/blok', $data);
    }
    
    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function blok_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Blok_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $blok) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($blok->id_blok).'"> '.$no;
            $row[] = tampil($blok->blok);
            $row[] = tampil($blok->cluster);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$blok->id_blok."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$blok->id_blok."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Blok_model->count_all(),
                        "recordsFiltered" => $this->Blok_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function blok_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[m3blok.blok]");
        $cluster = $this->input->post('cluster');
        $kode = $this->Blok_model->kodeauto($cluster,7);
        $data = array(
                'id_blok' => $kode,
                'blok' => $this->input->post('blok'),
                'id_cluster' => $this->input->post('cluster'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Blok_model->insert($data);
        datalogs(3, 'Menambahkan Data', 'Nama Blok : '.$this->input->post('blok'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function blok_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Blok_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function blok_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('blok') != $this->input->post('blokold')) {$vd="|is_unique[m3blok.blok]";} else {$vd="";}
        $this->_validate($vd);
        $data = array(
                'blok' => $this->input->post('blok'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Blok_model->update($data,$this->input->post('id'));
        datalogs(3, 'Mengubah Data', 'Data Blok : '.$this->input->post('blokold').' menjadi '.$this->input->post('blok'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function blok_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            datalogs(3, 'Menghapus Data', 'Menghapus Data Blok : '.$id,$id);
            $this->Blok_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function blok_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(3, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Blok',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Blok_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($blok) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'blok' => array(
                'field' => 'blok', 
                'label' => 'Blok Perumahan', 
                'rules' => 'trim|required|xss_clean'.$blok,
            ),
            'cluster' => array(
                'field' => 'cluster', 
                'label' => 'Cluster Perumahan', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('blok'))) {
                $data['inputerror'][] = 'blok';
                $data['error_string'][] = form_error('blok');
            }
            if(!empty(form_error('cluster'))) {
                $data['inputerror'][] = 'cluster';
                $data['error_string'][] = form_error('cluster');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}