<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporantunggakan extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Tagihan_model','Rumah_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporantunggakan', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_rumah' => $this->Rumah_model->get(NULL, NULL,"urut"),
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pelanggan() { 
        //'format' => [190, 236],
        $pelanggan = $this->input->post('tunggakannorumah');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $data['record_rumah'] = $this->Rumah_model->get2($pelanggan, TRUE);
        $data['record_tunggakan'] = $this->Tagihan_model->get_by2(array(' tb_tinvoice.no_rumah' => $pelanggan, 'status_bayar !=' => 'Sudah Bayar', 'jatuhtempo <=' =>date('Y-m').'-15'), "id_tagihan");
        $pdfFilePath = "laporantunggakanpelanggan_".time().".pdf";
        laporanpdf('laporan/tunggakan/pelanggan', $data, $set, "Laporan Tunggakan Per Pelanggan", $pdfFilePath);
    }

    public function cluster() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('tunggakancluster');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $where = array('status_bayar !=' => 'Sudah Bayar', 'jatuhtempo <=' =>date('Y-m').'-15');
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[0] ='Cluster : '.$ldata->cluster;
            $where2['id_cluster'] = $cluster;
        }
        $data['record_cluster'] = $this->Cluster_model->get_by2($where2, 'cluster');
        $data['record_tunggakan'] = $this->Tagihan_model->get_by2($where, "tgl_cetak");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporantunggakancluster_".time().".pdf";
        laporanpdf('laporan/tunggakan/cluster', $data, $set, "Laporan Tunggakan Per Cluster", $pdfFilePath);
    }
}