<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cluster extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Cluster_model','IPA_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/cluster', $data);
    }
    
    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = $this->IPA_model->get(NULL, NULL, 'id_ipa');
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function cluster_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Cluster_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $Cluster) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($Cluster->id_cluster).'"> '.$no;
            $row[] = tampil($Cluster->cluster);
            $row[] = tampil($Cluster->ipa);
            $row[] = tampil($Cluster->status_ipl);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$Cluster->id_cluster."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$Cluster->id_cluster."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Cluster_model->count_all(),
                        "recordsFiltered" => $this->Cluster_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function cluster_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[m2cluster.cluster]");
        $ipa = $this->input->post('ipa');
        $kode = $this->Cluster_model->kodeauto($ipa,5);
        $data = array(
                'id_cluster' => $kode,
                'cluster' => $this->input->post('cluster'),
                'id_ipa' => $ipa,
                'status_ipl' => $this->input->post('ipl'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Cluster_model->insert($data);
        datalogs(2, 'Menambahkan Data', 'Nama Cluster : '.$this->input->post('cluster'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function cluster_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Cluster_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function cluster_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('cluster') != $this->input->post('clusterold')) {$vd="|is_unique[m2cluster.cluster]";} else {$vd="";}
        $this->_validate($vd);
        $data = array(
                'cluster' => $this->input->post('cluster'),
                'status_ipl' => $this->input->post('ipl'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Cluster_model->update($data,$this->input->post('id'));
        datalogs(2, 'Mengubah Data', 'Data Cluster : '.$this->input->post('clusterold').' menjadi '.$this->input->post('cluster'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function cluster_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            datalogs(2, 'Menghapus Data', 'Menghapus Data Cluster : '.$id,$id);
            $this->Cluster_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function cluster_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(2, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Cluster',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Cluster_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($Cluster) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'cluster' => array(
                'field' => 'cluster', 
                'label' => 'Cluster Perumahan', 
                'rules' => 'trim|required|xss_clean'.$Cluster,
            ),
            'ipa' => array(
                'field' => 'ipa', 
                'label' => 'Instalasi Pengoahan Air', 
                'rules' => 'trim|required|xss_clean',
            )

        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('cluster'))) {
                $data['inputerror'][] = 'cluster';
                $data['error_string'][] = form_error('cluster');
            }
            if(!empty(form_error('ipa'))) {
                $data['inputerror'][] = 'ipa';
                $data['error_string'][] = form_error('ipa');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}