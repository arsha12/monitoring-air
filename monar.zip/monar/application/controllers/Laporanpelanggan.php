<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporanpelanggan extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Rumah_model','Cluster_model'));
        ini_set('max_execution_time', 300);
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporanpelanggan', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function daftarpelanggan() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('pelanggancluster');
        $status = $this->input->post('status');
        $kondisi = $this->input->post('kondisi');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $x=0;
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[$x] ='Cluster : '.$ldata->cluster;
            $x++;
        }
        if (!empty($status)) {
            $where['status_meter'] = $status;        
            $fill[$x] ='Status Meter : '.$status;
            $x++;
        }
        if (!empty($kondisi)) {
            $where['status_kondisi'] = $kondisi;           
            $fill[$x] ='Kondisi : '.$kondisi;
            $x++;
        }
        $data['filter'] = cekfilter($fill);
        $data['record_rumah'] = $this->Rumah_model->get_by2($where, "urut");
        $pdfFilePath = "laporanpelanggan_".time().".pdf";
        laporanpdf('laporan/pelanggan/all', $data, $set, "Daftar Pelanggan", $pdfFilePath);
    }

    public function bastpelanggan() { 
        //'format' => [190, 236],
        $bast = $this->input->post('bast');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $data['record_rumah'] = $this->Rumah_model->get_by2(array("status_bast" => $bast), "urut");
        $data['filter'] = $bast;
        $pdfFilePath = "laporanbastpelanggan_".time().".pdf";
        laporanpdf('laporan/pelanggan/bast', $data, $set, "Daftar BAST Pelanggan", $pdfFilePath);
    }

    public function pulsapelanggan() { 
        //'format' => [190, 236],
        $pulsa = $this->input->post('pulsa');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        if ($pulsa == "Sudah Habis") {
            $where = array("sisa_pulsa <=" => 0);
        } else {
            $where = array("sisa_pulsa >" => 0);
        }
        $data['record_rumah'] = $this->Rumah_model->get_by2($where, "urut");
        $data['filter'] = $pulsa;
        $pdfFilePath = "laporanpulsapelanggan_".time().".pdf";
        laporanpdf('laporan/pelanggan/pulsa', $data, $set, "Daftar Sisa Pulsa Pelanggan", $pdfFilePath);
    }

}