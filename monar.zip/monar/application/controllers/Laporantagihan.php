<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporantagihan extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Tagihan_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporantagihan', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }
    public function bulan() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('tagihancluster');
        $bulan = $this->input->post('tagihanbulan');
        $status = $this->input->post('status');
        $x = explode(' ',$bulan);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Bulan : '.$bulan;
        $where['month(jatuhtempo)'] = getIndexOfMonth($x[0]);
        $where['year(jatuhtempo)'] = $x[1];
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        if (!empty($status)) {
            $where['status_bayar'] = $status;
            $fill[2] ='Status Bayar : '.$status;
        }
        $data['record_tagihan'] = $this->Tagihan_model->get_by2($where, "urut");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporantagihanbulan_".time().".pdf";
        laporanpdf('laporan/tagihan/bulan', $data, $set, "Laporan Tagihan Per Bulan", $pdfFilePath);
    }

    public function tahun() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('tagihancluster1');
        $tahun = $this->input->post('tagihantahun');
        $status = $this->input->post('status');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tahun : '.$tahun;
        $where = 'WHERE year(a.jatuhtempo) ='.$tahun;
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where .= ' AND c.id_cluster = '.$cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        if (!empty($status)) {
            $where .= ' AND a.status_bayar = '.$status;
            $fill[2] ='Status Bayar : '.$status;
        }
        $data['record_tagihan'] = $this->Tagihan_model->getquery2("SELECT DISTINCT a.jatuhtempo, SUM(a.pakai) AS pakai, SUM(a.total_tagihan) AS jumlah FROM tb_tinvoice AS a INNER JOIN tb_mrumah AS b ON a.no_rumah = b.no_rumah INNER JOIN tb_m3blok AS c ON b.id_blok = c.id_blok ".$where." GROUP BY a.bulan ORDER BY a.tgl_cetak");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporantagihantahun_".time().".pdf";
        laporanpdf('laporan/tagihan/tahun', $data, $set, "Laporan Tagihan Per Tahun", $pdfFilePath);
    }
}