<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporangantimeteran extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Gantimeter_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporangantimeteran', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function tanggal() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('gantimeterancluster');
        $tanggal = $this->input->post('gantimeterantanggal');
        $x = explode('/',$tanggal);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tanggal : '.$x[0].' '.getNameOfMonth($x[1]).' '.$x[2];
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $where['tanggal_ganti'] = date($x[2]."/".$x[1]."/".$x[0]);
        $data['record_gantimeter'] = $this->Gantimeter_model->get_by2($where, "id_gantimeter");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporangantimeterantanggal_".time().".pdf";
        laporanpdf('laporan/gantimeter/daftar', $data, $set, "Laporan Ganti Meteran Per Hari", $pdfFilePath);
    }

    public function bulan() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('gantimetercluster1');
        $bulan = $this->input->post('gantimeteranbulan');
        $x = explode(' ',$bulan);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Bulan : '.$bulan;
        $where['month(tanggal_ganti)'] = getIndexOfMonth($x[0]);
        $where['year(tanggal_ganti)'] = $x[1];
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $data['record_gantimeter'] = $this->Gantimeter_model->get_by2($where, "id_gantimeter");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporangantimeteranbulan_".time().".pdf";
        laporanpdf('laporan/gantimeter/daftar', $data, $set, "Laporan Ganti Meteran Per Bulan", $pdfFilePath);
    }

    public function periode() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('gantimetercluster2');
        $periode = $this->input->post('gantimeterperiode');
        $x = explode(' - ',$periode);
        $y1 = explode('/',$x[0]); 
        $y2 = explode('/',$x[1]);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $per = $y1[0].' '.getNameOfMonth($y1[1]).' '.$y1[2].' - '.$y2[0].' '.getNameOfMonth($y2[1]).' '.$y2[2];
        $fill[0] ='Bulan : '.$per;
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $where['tanggal_ganti >='] = date($y1[2]."/".$y1[1]."/".$y1[0]);
        $where['tanggal_ganti <='] = date($y2[2]."/".$y2[1]."/".$y2[0]);
        $data['record_gantimeter'] = $this->Gantimeter_model->get_by2($where, "id_gantimeter");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporangantimeterperiode_".time().".pdf";
        laporanpdf('laporan/gantimeter/daftar', $data, $set, "Laporan Ganti Meteran Periode", $pdfFilePath);
    }

}