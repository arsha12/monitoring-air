<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class IPA extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('IPA_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/ipa', $data);
    }

    public function ipa_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->IPA_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $ipa) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($ipa->id_ipa).'"> '.$no;
            $row[] = tampil($ipa->ipa);

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$ipa->id_ipa."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$ipa->id_ipa."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->IPA_model->count_all(),
                        "recordsFiltered" => $this->IPA_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function ipa_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[m1ipa.ipa]");
        $kode = $this->IPA_model->kodeauto('',3);
        $data = array(
            'id_ipa' => $kode,
            'ipa' => $this->input->post('ipa'),
        );
        $insert = $this->IPA_model->insert($data);
        datalogs(1, 'Menambahkan Data', 'Nama IPA : '.$this->input->post('ipa'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function ipa_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->IPA_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function ipa_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('ipa') != $this->input->post('ipaold')) {$vd="|is_unique[m1ipa.ipa]";} else {$vd="";}
        $this->_validate($vd);
        $data = array(
            'ipa' => $this->input->post('ipa'),
        );
        $this->IPA_model->update($data,$this->input->post('id'));
        datalogs(1, 'Mengubah Data', 'Data IPA : '.$this->input->post('ipaold').' menjadi '.$this->input->post('ipa'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function ipa_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            datalogs(1, 'Menghapus Data', 'Menghapus Data IPA : '.$id,$id);
            $this->IPA_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function ipa_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(1, 'Menghapus Data', 'Menghapus '.count($list_id).' Data IPA',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->IPA_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($ipa) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'ipa' => array(
                'field' => 'ipa', 
                'label' => 'Nama IPA', 
                'rules' => 'trim|required|xss_clean'.$ipa,
            )
        );  
        $pesan = $this->IPA_model->rulepesan;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        $this->form_validation->set_message($pesan);
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('ipa'))) {
                $data['inputerror'][] = 'ipa';
                $data['error_string'][] = form_error('ipa');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}