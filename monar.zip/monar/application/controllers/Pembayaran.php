<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembayaran extends Backend_Controller {
	public function __construct(){
		parent::__construct();
        $this->load->model(array('Bayar_model','Bayardetail_model','Tagihan_model','Tagihandetail_model','Rumah_model','Setlain_model','Setperiode_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/bayar', $data);
    }

   public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_rumah' => $this->Rumah_model->get(NULL, NULL, 'urut'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

   public function ambil_denda($date){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_denda' => $this->Setlain_model->get2("3".substr($date,2,2), TRUE),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pembayaran_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $g = $this->Setperiode_model->get_by(array('status' => 'Active'),NULL,NULL,NULL, TRUE);
            $data = array(
                'record_denda' => $this->Setlain_model->get(),
                'record_tagihan' => $this->Tagihan_model->get_by(array("no_rumah" => $id, "status_bayar" => "Belum Bayar", "jatuhtempo <=" => date('Y-m').'-15'), "id_tagihan"),
            );
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pembayaran_preview($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_bayar' => $this->Bayar_model->get2($id, TRUE),
                'record_detail' => $this->Bayardetail_model->get_by2(array("id_bayar" => $id),"id_bayardetail"),
            );
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function cetak_bukti() { 
        //'format' => [190, 236],
        $id = $this->input->post('id');
        $setting = ['mode' => 'utf-8', 'format' => [210, 148.5], 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $this->load->library('pdf');
        $mpdf = $this->pdf->load($setting);
        $stylesheet = file_get_contents(site_url().'assets/logo/laporan2.css');
        $mpdf->WriteHTML($stylesheet,1);
        $mpdf->SetTitle("Bukti Pembayaran");
        $mpdf->SetAuthor("Talang Sari Lestari");
        $mpdf->SetHTMLHeader('
        <table width="100%">
        <tr>
          <td width="15%" rowspan="2" align="center"><img src="'.site_url().'assets/logo/logo.jpg" width="80px" /></td>
          <td width="85%" class="company">PT. TALANG SARI LESTARI</td>
        </tr>
        <tr>
          <td class="address">Jalan Perumahan Talang Sari (Kantor Pemasaran) Blok AA No 15A, Kel. Tanah Merah, Kec. Samarinda Utara, Telpon : 0858 4552 0042</td>
        </tr>
        </table>');
        $pdfFilePath = "cetakbukti_".time().".pdf";
        $data = array(
            'record_bayar' =>  $this->Bayar_model->get2($id, TRUE),
            'record_detail' => $this->Bayardetail_model->get_by2(array("id_bayar" => $id),"id_bayardetail"),
        );
        $data['sign'] = get_user_info('nama');
        $data['laporan'] = 'Bukti Pembayaran';
        $data['materai'] = site_url().'assets/logo/materai.bmp';        
        $this->site->view('laporan/pembayaran/bukti', $data, true);
        $html = $this->output->get_output();                      
        //$mpdf->SetProtection(array('copy','print','modify','extract'), '', 'MyPassword');
        $mpdf->SetWatermarkText("LUNAS");
        $mpdf->showWatermarkText = true;
        $mpdf->watermark_font = 'DejaVuSansCondensed';
        $mpdf->watermarkTextAlpha = 0.1;
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
        exit;
    }

    public function pembayaran_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $list = $this->Bayar_model->get_datatables(array('tgl_bayar' => date('Y-m-d')));
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $pembayaran) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($pembayaran->id_bayar).'"> '.$no;
            $row[] = tampil($pembayaran->no_bayar);
            $row[] = tampil(tgl_indo2($pembayaran->tgl_bayar));
            $row[] = tampil($pembayaran->no_rumah);
            $row[] = tampil($pembayaran->keterangan);
            $row[] = '<div align="right">'.tampil(curen($pembayaran->bayar)).'</div>';
            $row[] = '<a class="btn btn-sm btn-info" href="javascript:void(0)" title="Lihat bayar" onclick="view_data('."'".$pembayaran->id_bayar."'".')"><i class="glyphicon glyphicon-eye-open"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$pembayaran->id_bayar."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Bayar_model->count_all(array('tgl_bayar' => date('Y-m-d'))),
                        "recordsFiltered" => $this->Bayar_model->count_filtered(array('tgl_bayar' => date('Y-m-d'))),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pembayaran_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate();
        $idtagihan = $this->input->post('idtagihan');
        $norumah   = $this->input->post('norumah');
        $bulan     = $this->input->post('bulan');
        $tagihan   = $this->input->post('tagihan');
        $denda     = $this->input->post('denda');
        $total     = $this->input->post('total');

        $jumlah_dipilih = count($idtagihan);
        if ($jumlah_dipilih > 0) {
            for($x=0;$x<$jumlah_dipilih;$x++){
                $xket[] = $bulan[$x]; 
                $xgrand[] = $total[$x]; 
            }
            $datx = date("y")."-".date("m")."-".date("d");
            $kode = $this->Bayar_model->kodeauto(date("ymd"),11);
            $data = array(
                    'id_bayar' => $kode,
                    'no_bayar' => "LNS/WTP/".$datx."/".substr($kode, -4),
                    'tgl_bayar' => date('Y-m-d'),
                    'no_rumah' => $norumah,
                    'keterangan' => implode(", ", $xket),
                    'bayar' => array_sum($xgrand),
                    //'users'=> get_user_info('ID'),
                    //'created'=>date('Y-m-d H:i:s')
            );
            $insert = $this->Bayar_model->insert($data);
            for($x=0;$x<$jumlah_dipilih;$x++){
                $kode2 = $this->Bayardetail_model->kodeauto($kode,13);
                $this->SimpanDetail($kode2, $kode, $idtagihan[$x], $tagihan[$x], $denda[$x], $total[$x]);
                $data3 = array(
                    'total_bayar' => $total[$x],
                    'status_bayar' => "Sudah Bayar", 
                );
                $this->Tagihan_model->update($data3,$idtagihan[$x]);
            }
        }
        datalogs(9, 'Menambahkan Data', 'Data Pembayaran : '.$this->input->post('norumah'),json_encode($idtagihan));   
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pembayaran_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            datalogs(9, 'Menghapus Data', 'Menghapus Data Pembayaran : '.$id,$id);
            $list = $this->Bayardetail_model->get_by(array("id_bayar" => $id));
            foreach ($list as $b) {
            $data3 = array(
                'total_bayar' => '0',
                'status_bayar' => "Belum Bayar", 
            );
            $this->Tagihan_model->update($data3,$b->id_tagihan);
            }
            $this->Bayar_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pembayaran_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(9, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Pembayaran',json_encode($list_id));
        foreach ($list_id as $id) {
            $list = $this->Bayardetail_model->get_by(array("id_bayar" => $id));
            foreach ($list as $b) {
            $data3 = array(
                'total_bayar' => '0',
                'status_bayar' => "Belum Bayar", 
            );
            $this->Tagihan_model->update($data3,$b->id_tagihan);
            }
            $this->Bayar_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function SimpanDetail($kode, $id, $idtagihan, $tagihan, $denda, $total) {
        $data2 = array(
                'id_bayardetail' => $kode,
                'id_bayar' => $id,
                'id_tagihan' => $idtagihan,
                'tagihan' => $tagihan,
                'denda' => $denda,
                'total' => $total,
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $in = $this->Bayardetail_model->insert($data2);
    }

    private function _validate() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}