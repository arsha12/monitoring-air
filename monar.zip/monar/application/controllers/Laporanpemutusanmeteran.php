<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporanpemutusanmeteran extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Pemutusan_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporanpemutusanmeteran', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

     public function tanggal() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('pemutusancluster');
        $tanggal = $this->input->post('pemutusantanggal');
        $x = explode('/',$tanggal);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tanggal : '.$x[0].' '.getNameOfMonth($x[1]).' '.$x[2];
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $where['tanggal_pemutusan'] = date($x[2]."/".$x[1]."/".$x[0]);
        $data['record_pemutusan'] = $this->Pemutusan_model->get_by2($where, "id_pemutusan");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpemutusantanggal_".time().".pdf";
        laporanpdf('laporan/pemutusan/daftar', $data, $set, "Laporan Pemutusan Per Hari", $pdfFilePath);
    }

    public function bulan() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('pemutusancluster');
        $bulan = $this->input->post('pemutusanbulan');
        $x = explode(' ',$bulan);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Bulan : '.$bulan;
        $where['month(tanggal_pemutusan)'] = getIndexOfMonth($x[0]);
        $where['year(tanggal_pemutusan)'] = $x[1];
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $data['record_pemutusan'] = $this->Pemutusan_model->get_by2($where, "id_pemutusan");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpemutusanbulan_".time().".pdf";
        laporanpdf('laporan/pemutusan/daftar', $data, $set, "Laporan Pemutusan Per Bulan", $pdfFilePath);
    }

    public function periode() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('pemutusancluster');
        $periode = $this->input->post('pemutusanperiode');
        $x = explode(' - ',$periode);
        $y1 = explode('/',$x[0]); 
        $y2 = explode('/',$x[1]);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $per = $y1[0].' '.getNameOfMonth($y1[1]).' '.$y1[2].' - '.$y2[0].' '.getNameOfMonth($y2[1]).' '.$y2[2];
        $fill[0] ='Bulan : '.$per;
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $where['tanggal_pemutusan >='] = date($y1[2]."/".$y1[1]."/".$y1[0]);
        $where['tanggal_pemutusan <='] = date($y2[2]."/".$y2[1]."/".$y2[0]);
        $data['record_pemutusan'] = $this->Pemutusan_model->get_by2($where, "id_pemutusan");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpemutusanperiode_".time().".pdf";
        laporanpdf('laporan/pemutusan/daftar', $data, $set, "Laporan Pemutusan Periode", $pdfFilePath);
    }
}