<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends Backend_Controller {	
	public function __construct(){
		parent::__construct();		
		$this->load->model(array('Pengguna_model'));
	}

	public function index(){
		$data = array();
		$this->site->view('login', $data);		
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(set_url('login'));
	}

	public function lupa_password(){
		global $SConfig;

		$this->form_validation->set_message('required', '%s kosong, tolong diisi!');

		$rules = $this->Pengguna_model->rules_forgot;
		$this->form_validation->set_rules($rules);	
		$post = $this->input->post(NULL,TRUE);

		if ($this->form_validation->run() == FALSE){	
			$this->site->view('lupa_password');
        }
        else{
        	$this->site->view('reset_password');
        	$rand_password = random_string(8);
			$data['password'] = bCrypt($rand_password,12);
			$this->Pengguna_model->update($data, array('email' => $post['email']));

			$user_detail = $this->Pengguna_model->get_by(array('email' => $post['email']), 1, NULL, TRUE);

			// echo $rand_password;

			/* SENDING EMAIL */
			$this->load->library('email');
			$config['mailtype'] = 'html';
			$this->email->initialize($config);

			$this->email->from('noreply@'.$SConfig->_site_name, 'NoREPLY');
			$this->email->to($post['email']);

			$this->email->subject('Reset Password Login '.$SConfig->_site_name.' Berhasil !!!');
			$this->email->message("Berikut adalah Info login Anda : \n\nUsername: ".$user_detail->username."\nPassword: ".$rand_password."\nSilahkan login di ".$SConfig->_site_name."/admin/login");

			$this->email->send();	
		}
	}

}
