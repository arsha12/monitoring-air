<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Distribusi extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Distribusi_model','IPA_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/distribusi', $data);
    }
    
    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_ipa' => $this->IPA_model->get(NULL, NULL, 'id_ipa'),
            );                
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function distribusi_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Distribusi_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $Distribusi) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($Distribusi->id_distribusi).'"> '.$no;
            $row[] = tampil(tgl_arsip($Distribusi->tgl));
            $row[] = tampil($Distribusi->ipa);
            $row[] = '<div align="right">'.tampil(curen($Distribusi->jumlah)).' M<sup>3</sup></div>';
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$Distribusi->id_distribusi."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$Distribusi->id_distribusi."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Distribusi_model->count_all(),
                        "recordsFiltered" => $this->Distribusi_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function distribusi_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("");
        $bulan     = $this->input->post('bulan');
        $ipa     = $this->input->post('ipa');
        $jumlah  = $this->input->post('jumlah');
        $x = explode(' ',$bulan);
        $p = getIndexOfMonth($x[0]);
        foreach($jumlah as $i=>$val) {
        $data = array(
                'id_distribusi' => "D".substr($x[1],2,2).$p.$ipa[$i],
                'bulan' => $bulan,
                'id_ipa' => $ipa[$i],
                'jumlah' => $jumlah[$i],
                'tgl' => $x[1].'-'.$p.'-25',
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Distribusi_model->insert($data);
        }
        datalogs(7, 'Menambahkan Data', 'Data Distribusi Bulan : '.$this->input->post('bulan'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function distribusi_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Distribusi_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function ipa_lihat($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->IPA_model->get2(substr($id,5,2));
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }


    public function distribusi_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("");
        $jumlah  = $this->input->post('jumlah');
        foreach($jumlah as $i=>$val) {
        $data = array(
                'jumlah' => $jumlah[$i],
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Distribusi_model->update($data,$this->input->post('id'));
        }
        datalogs(7, 'Merubah Data', 'Data Distribusi Bulan : '.$this->input->post('bulan'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function distribusi_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Distribusi_model->delete($id);
            datalogs(7, 'Menghapus Data', 'Menghapus Data Distribusi : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function distribusi_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(7, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Distribusi',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Distribusi_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($Bulan) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'bulan' => array(
                'field' => 'bulan', 
                'label' => 'Bulan Distribusi', 
                'rules' => 'trim|required|xss_clean'.$Bulan,
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  

        $jumlah        = $this->input->post('jumlah');
        foreach($jumlah as $ind=>$val) {
            $jum  = $jumlah[$ind];
            $this->form_validation->set_rules("jumlah[".$ind."]", "Jumlah", "trim|required|xss_clean|greater_than_equal_to[1]");
        }
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('bulan'))) {
                $data['inputerror'][] = 'bulan';
                $data['error_string'][] = form_error('bulan');
            }
            for($i = 0; $i < count($jumlah); $i++) {
                if(!empty(form_error("jumlah[".$i."]"))) {
                    $data['inputerror'][] = "jumlah[".$i."]";
                    $data['error_string'][] = form_error("jumlah[".$i."]");
                }
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}