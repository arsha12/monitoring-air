<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporanpembayaran extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Bayar_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporanpembayaran', $data);
    }

    public function tanggal() { 
        //'format' => [190, 236],
        $tanggal = $this->input->post('pembayarantanggal');
        $x = explode('/',$tanggal);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tanggal : '.$x[0].' '.getNameOfMonth($x[1]).' '.$x[2];
        $where = array();
        $where['tgl_bayar'] = date($x[2]."/".$x[1]."/".$x[0]);
        $data['record_pembayaran'] = $this->Bayar_model->get_by2($where, "no_bayar");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpembayarantanggal_".time().".pdf";
        laporanpdf('laporan/pembayaran/tanggal', $data, $set, "Laporan Pembayaran Per Hari", $pdfFilePath);
    }

    public function bulan() { 
        //'format' => [190, 236],
        $bulan = $this->input->post('pembayaranbulan');
        $x = explode(' ',$bulan);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Bulan : '.$bulan;
        $where = 'WHERE month(tgl_bayar) ='.getIndexOfMonth($x[0]);
        $where .= ' AND year(tgl_bayar) ='.$x[1];
        $data['record_pembayaran'] = $this->Bayar_model->getquery2("SELECT DISTINCT tgl_bayar, SUM(bayar) as total, count(id_bayar) as jumlah FROM tb_tbayar ".$where." GROUP BY tgl_bayar");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpembayaranbulan_".time().".pdf";
        laporanpdf('laporan/pembayaran/bulan', $data, $set, "Laporan Pembayaran Per Bulan", $pdfFilePath);
    }

    public function periode() { 
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 300);
        //'format' => [190, 236],
        $periode = $this->input->post('pembayaranperiode');
        $x = explode(' - ',$periode);
        $y1 = explode('/',$x[0]); 
        $y2 = explode('/',$x[1]);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $per = $y1[0].' '.getNameOfMonth($y1[1]).' '.$y1[2].' - '.$y2[0].' '.getNameOfMonth($y2[1]).' '.$y2[2];
        $fill[0] ='Bulan : '.$per;
        $where = array();
        $where['tgl_bayar >='] = date($y1[2]."/".$y1[1]."/".$y1[0]);
        $where['tgl_bayar <='] = date($y2[2]."/".$y2[1]."/".$y2[0]);
        $data['record_pembayaran'] = $this->Bayar_model->get_by2($where, "no_bayar");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpembayaranperiode_".time().".pdf";
        laporanpdf('laporan/pembayaran/periode', $data, $set, "Laporan Pembayaran Periode", $pdfFilePath);
    }

    public function tahun() { 
        //'format' => [190, 236],
        $tahun = $this->input->post('pembayarantahun');
        $pulsa = $this->input->post('pulsa');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tahun : '.$tahun;
        $where = 'WHERE year(tgl_bayar) ='.$tahun;
        $data['record_pembayaran'] = $this->Bayar_model->getquery2("SELECT DISTINCT tgl_bayar, SUM(bayar) as total, count(id_bayar) as jumlah FROM tb_tbayar ".$where." GROUP BY MONTH(tgl_bayar)");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporanpembayarantahun_".time().".pdf";
        laporanpdf('laporan/pembayaran/tahun', $data, $set, "Laporan Pembayaran Per Tahun", $pdfFilePath);
    }
}