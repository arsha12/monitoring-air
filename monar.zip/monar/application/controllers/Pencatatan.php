<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pencatatan extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Rumah_model','Cluster_model'));
        ini_set('max_execution_time', 300);
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterpencatatan', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function formulir() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('pencatatancluster');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $x=0;
        $where["status_meter"] = "Aktif";
        $where["status_kondisi"] = "Berpenghuni";
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[$x] ='Cluster : '.$ldata->cluster;
            $x++;
        }
        $data['filter'] = cekfilter($fill);
        $data['record_rumah'] = $this->Rumah_model->get_by2($where, "urut");
        $pdfFilePath = "formulirpencatatan_".time().".pdf";
        laporanpdf('laporan/pencatatan/formulir', $data, $set, "Formulir Pencatatan", $pdfFilePath);
    }
}