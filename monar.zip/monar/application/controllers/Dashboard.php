<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Backend_Controller {
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$data = array();
		if (get_user_info('group')=='calon anggota') { $vie = 'index_user'; } else { $vie = 'index'; }
		$this->site->view($vie, $data);
	}

	public function action($param){
		global $SConfig;
		if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
			if($param=='ambil'){
		        $jum_pelanggan = 0;
		        $this->load->model(array('Rumah_model','Tagihan_model','Bayar_model','Logs_model','Pengguna_model'));
		        $m = $this->Tagihan_model->getquery("SELECT count(id_tagihan) as jum, no_rumah FROM tb_tinvoice where status_bayar != 'Sudah Bayar' AND jatuhtempo <= '".date('Y-m').'-15'."' Group By no_rumah");
	            foreach ($m as $b) {
	            	if ($b->jum > 1) {
	            		$jum_pelanggan += 1;
	            	}
	            }

				echo json_encode(array(
					'user' => get_user_info('ID'),
					'record_user' => $this->Pengguna_model->get(),
					'data_tanggallogs'	=> $this->Logs_model->getquery("SELECT DISTINCT tanggal AS tanggal FROM tb_logs ORDER BY tanggal DESC LIMIT 3"),
					'data_logs'	=> $this->Logs_model->get(),
					'jum_tunggakan' => $jum_pelanggan,
					'jum_pembayaran' => $this->Bayar_model->count(array('tgl_bayar' => date('Y-m-d'))),
					'jum_pelanggan' => $this->Rumah_model->count(array("status_meter" => "Aktif")),
					'grafik_pelanggan' => $this->Rumah_model->getquery("SELECT DISTINCT c.cluster AS cluster, COUNT(a.no_rumah) AS jumlah FROM tb_mrumah AS a INNER JOIN tb_m3blok AS b ON a.id_blok = b.id_blok INNER JOIN tb_m2cluster AS c ON b.id_cluster = c.id_cluster WHERE a.status_meter = 'Aktif' GROUP BY c.cluster")
				));
			}
		}
	}	

    public function ambil_profile() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
		$this->load->model(array('Pengguna_model'));
        $data = $this->Pengguna_model->get_by(array('username' => get_user_info('username')), NULL, 1, NULL, TRUE);;
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

}
