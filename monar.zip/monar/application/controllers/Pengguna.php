<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Pengguna_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('module/pengguna', $data);
    }

    public function login(){
        $data = array();
        $this->site->view('login', $data);      
    }

    public function logout(){
        $this->session->sess_destroy();
        redirect(set_url('pengguna/login'));
    }

    public function pengguna_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Pengguna_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $pengguna) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($pengguna->id_akun).'"> '.$no;
            $row[] = tampil($pengguna->nama_akun);
            $row[] = tampil($pengguna->username);
            $row[] = tampil($pengguna->email);
            $row[] = tampil($pengguna->handphone);
            $row[] = tampil($pengguna->level);
            $row[] = tampil($pengguna->aktif);

            if($pengguna->foto_akun)
                $row[] = '<a href="'.base_url('uploads/foto_akun/'.tampil($pengguna->foto_akun)).'" data-fancybox="images" data-caption="'.tampil($pengguna->nama_akun).'"><img src="'.base_url('uploads/foto_akun/small_'.tampil($pengguna->foto_akun)).'" class="img-responsive img-thumbnail" /></a>';
            else
                $row[] = '(No Image)';

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$pengguna->id_akun."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$pengguna->id_akun."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Pengguna_model->count_all(),
                        "recordsFiltered" => $this->Pengguna_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengguna_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("|is_unique[akun.email]","|is_unique[akun.username]");
        $tg = '1'.date("ym");
        $kode = $this->Pengguna_model->kodeauto($tg,9);
        $data = array(
                'id_akun' => $kode,
                'username' => $this->input->post('username'),
                'nama_akun' => $this->input->post('nama'),
                'handphone' => str_replace("_","",$this->input->post('handphone')),
                'alamat' => $this->input->post('alamat'),
                'email' => $this->input->post('email'),
                'level' => $this->input->post('level'),
                'created'=>date('Y-m-d H:i:s')
        );
        if(!empty($this->input->post('password'))) {
            $data['password'] = bCrypt($this->input->post('password'),12);            
        }
        if(!empty($_FILES['foto']['name'])) {
            $upload = $this->_do_upload();
            $data['foto_akun'] = $upload;
        }
        $insert = $this->Pengguna_model->insert($data);
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengguna_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Pengguna_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengguna_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('email') != $this->input->post('emailold')) {$nemail="|is_unique[akun.email]";} else {$nemail="";}
        if ($this->input->post('username') != $this->input->post('usernameold')) {$nuser="|is_unique[akun.username]";} else {$nuser="";}
        $this->_validate($nemail,$nuser);
        $data = array(
                'nama_akun' => $this->input->post('nama'),
                'username' => $this->input->post('username'),
                'handphone' => str_replace("_","",$this->input->post('handphone')),
                'alamat' => $this->input->post('alamat'),
                'email' => $this->input->post('email'),
                'edited'=>date('Y-m-d H:i:s')
        );
        if(!empty($this->input->post('password'))) {
            $data['password'] = bCrypt($this->input->post('password'),12);            
        }
        if(!empty($_FILES['foto']['name'])) {
            $upload = $this->_do_upload();
            $dpengguna = $this->Pengguna_model->get($this->input->post('id'));
            if(file_exists('uploads/foto_akun/'.$dpengguna->foto_akun) && $dpengguna->foto_akun) {
                unlink('uploads/foto_akun/'.$dpengguna->foto_akun);
                unlink('uploads/foto_akun/small_'.$dpengguna->foto_akun);
            }
            $data['foto_akun'] = $upload;
        }
        $this->Pengguna_model->update($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengguna_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $dpengguna = $this->Pengguna_model->get($id);
            if(file_exists('uploads/foto_akun/'.$dpengguna->foto_akun) && $dpengguna->foto_akun) {
                unlink('uploads/foto_akun/'.$dpengguna->foto_akun);
                unlink('uploads/foto_akun/small_'.$dpengguna->foto_akun);
            }
            $this->Pengguna_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pengguna_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        foreach ($list_id as $id) {
            $dpengguna = $this->Pengguna_model->get($id);
            if(file_exists('uploads/foto_akun/'.$dpengguna->foto_akun) && $dpengguna->foto_akun) {
                unlink('uploads/foto_akun/'.$dpengguna->foto_akun);
                unlink('uploads/foto_akun/small_'.$dpengguna->foto_akun);
            }
            $this->Pengguna_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _do_upload() {
        $config['upload_path']          = 'uploads/foto_akun/';
        $config['allowed_types']        = 'gif|jpg|png|JPG|JPEG';
        $config['max_size']             = 3000; //set max size allowed in Kilobyte
        //$config['max_width']            = 1000; // set max width image allowed
        //$config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique nam
        $config['encrypt_name']         = true; //just milisecond timestamp fot unique nam
        $this->load->library('upload', $config);
        if(!$this->upload->do_upload('foto')) {
            $data['inputerror'][] = 'foto';
            $data['error_string'][] = 'Upload error: '.$this->upload->display_errors('',''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        } else {
            $config['image_library'] = 'gd2';
            $config['source_image'] = $this->upload->data('full_path');
            $config['new_image'] = 'uploads/foto_akun/small_'.$this->upload->data('file_name');
            $config['maintain_ratio'] = true;
            $config['width'] = 200;
            $config['height'] = 200;
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();
        }
        return $this->upload->data('file_name');
    }

    private function _validate($email,$user) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'nama' => array(
                'field' => 'nama', 
                'label' => 'Nama Pengguna', 
                'rules' => 'trim|required|xss_clean',
            ),
            'alamat' => array(
                'field' => 'alamat', 
                'label' => 'Alamat Tinggal', 
                'rules' => 'trim|required|xss_clean',
            ),
            'handphone' => array(
                'field' => 'handphone', 
                'label' => 'Nomor Handphone', 
                'rules' => 'trim|required|xss_clean',
            ),
            'email' => array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|xss_clean|valid_email'.$email,
            ),
            'username' => array(
                'field' => 'username',
                'label' => 'Username',
                'rules' => 'trim|required|xss_clean'.$user,
            ),
            'password' => array(
                'field' => 'password', 
                'label' => 'Password', 
                'rules' => 'trim|xss_clean|min_length[6]',
            ),
            'repassword' => array(
                'field' => 'repassword', 
                'label' => 'Re-Password', 
                'rules' => 'trim|xss_clean|min_length[6]|matches[password]',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('nama'))) {
                $data['inputerror'][] = 'nama';
                $data['error_string'][] = form_error('nama');
            }            
            if(!empty(form_error('alamat'))) {
                $data['inputerror'][] = 'alamat';
                $data['error_string'][] = form_error('alamat');
            }
            if(!empty(form_error('handphone'))) {
                $data['inputerror'][] = 'handphone';
                $data['error_string'][] = form_error('handphone');
            }
            if(!empty(form_error('email'))) {
                $data['inputerror'][] = 'email';
                $data['error_string'][] = form_error('email');
            }
            if(!empty(form_error('username'))) {
                $data['inputerror'][] = 'username';
                $data['error_string'][] = form_error('username');
            }
            if(!empty(form_error('password'))) {
                $data['inputerror'][] = 'password';
                $data['error_string'][] = form_error('password');
            }
            if(!empty(form_error('repassword'))) {
                $data['inputerror'][] = 'repassword';
                $data['error_string'][] = form_error('repassword');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}