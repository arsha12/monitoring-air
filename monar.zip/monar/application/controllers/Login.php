<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends Login_Controller {	
	protected $user_detail;

	public function __construct(){
		parent::__construct();		
		$this->load->model(array('Login_model'));
	}

	public function index(){
		$data = array();
		$this->site->view('login', $data);		
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(set_url('login'));
	}
	
    private function _validateverifi() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = $this->Login_model->rules;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('username'))) {
                $data['inputerror'][] = 'username';
                $data['error_string'][] = form_error('username');
            }
            if(!empty(form_error('password'))) {
                $data['inputerror'][] = 'password';
                $data['error_string'][] = form_error('password');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

	public function verifikasi_login(){
		/* tahap 3 finishing */		
		$this->user_detail = $this->Login_model->get_by(array('username' => $this->input->post('username'), 'aktif' => 'Y'), NULL, 1, NULL, TRUE);
		$this->form_validation->set_message('required', '%s kosong, tolong diisi!');
		$this->_validateverifi();
		$lastlog = date('Y-m-d H:i:s');
		$login_data = array(
			'ID' => $this->user_detail->id_akun,
			'username'  => $this->input->post('username'),			        
			'nama'  => $this->user_detail->nama_akun,			        
			'foto'  => $this->user_detail->foto_akun,			        
			'logged_in' => TRUE,
			'active' => $this->user_detail->aktif,
			'last_login' => $lastlog,
			'sejak' => $this->user_detail->created,
			'group' => $this->user_detail->level,
		);						
	    $this->session->set_userdata($login_data);
		$this->session->set_userdata('KCFINDER', array('disabled' => true));
        $data = array('last_login' => $lastlog);
        $this->Login_model->update($data,$this->user_detail->id_akun);
		$_SESSION['ses_kcfinder']=array();
		$_SESSION['ses_kcfinder']['disabled'] = false;
		if(isset($post['remember']) ){
			$expire = time() + (86400 * 7);
			set_cookie('username', $this->input->post('username'), $expire , "/");
			set_cookie('password', $this->input->post('password'), $expire , "/" );
		}
        echo json_encode(array("status" => TRUE));
    }

	public function password_check($str){
    	$user_detail =  $this->user_detail;  	
    	if (@$user_detail->password == crypt($str,@$user_detail->password)){
			return TRUE;
		}
		else if(@$user_detail->password){
			$this->form_validation->set_message('password_check', 'Passwordnya Anda Salah ...');
			return FALSE;
		}else{
			$this->form_validation->set_message('password_check', 'Anda tidak punya Akses Admin Portal ...');
			return @$user_detail;	
		}		
	}	
}
