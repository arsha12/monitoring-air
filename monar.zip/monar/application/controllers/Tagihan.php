<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tagihan extends Backend_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model(array('Tagihan_model','Tagihandetail_model','Rumah_model','Cluster_model','Setharga_model','Setlain_model','Setperiode_model','Blok_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('module/tagihan', $data);
    }
    
    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
                'record_blok' => $this->Blok_model->get(NULL, NULL, 'id_blok'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function tagihan_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $a = explode(".",$id);
            $data = array(
                'record_rumah' => $this->Rumah_model->get_by2(array("tb_m3blok.id_cluster" => $a[0], "status_meter" => "Aktif", "status_kondisi" => "Berpenghuni", "tanggal_aktivasi <=" => $a[2]."-".getIndexOfMonth($a[1])."-".date('d')), "urut"),
                'record_tagihan' => $this->Tagihan_model->get_by(array("bulan" => substr($a[1],0,3)." ".substr($a[2],2,2))),
            );
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function tagihan_preview($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_tagihan' =>  $this->Tagihan_model->get2($id, TRUE),
                'record_detail' => $this->Tagihandetail_model->get_by2(array("id_tagihan" => $id),"id_tagihandetail"),
            );
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function tagihan_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $list = $this->Tagihan_model->get_datatables(array("status_bayar !=" => "Sudah Bayar"));
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $tagihan) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($tagihan->id_tagihan).'"> '.$no;
            $row[] = tampil($tagihan->no_tagihan);
            $row[] = tampil($tagihan->no_rumah);
            $row[] = tampil($tagihan->nm_customer);
            $row[] = tampil($tagihan->bulan);
            $row[] = '<div align="right">'.tampil(curen($tagihan->total_tagihan)).'</div>';
            $row[] = '<a class="btn btn-sm btn-info" href="javascript:void(0)" title="Lihat Tagihan" onclick="view_data('."'".$tagihan->id_tagihan."'".')"><i class="glyphicon glyphicon-eye-open"></i></a>
                <a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$tagihan->id_tagihan."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$tagihan->id_tagihan."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Tagihan_model->count_all(array("status_bayar !=" => "Sudah Bayar")),
                        "recordsFiltered" => $this->Tagihan_model->count_filtered(array("status_bayar !=" => "Sudah Bayar")),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }  

    public function cetak_tagihan() { 
        //'format' => [190, 236],
        $id = $this->input->post('id');
        $setting = ['mode' => 'utf-8', 'format' => 'A4', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $this->load->library('pdf');
        $mpdf = $this->pdf->load($setting);
        $stylesheet = file_get_contents(site_url().'assets/logo/laporan2.css');
        $mpdf->WriteHTML($stylesheet,1);
        $mpdf->SetTitle("Tagihan Air");
        $mpdf->SetAuthor("Talang Sari Lestari");
        $mpdf->SetHTMLHeader('
        <table width="100%">
        <tr>
          <td width="15%" rowspan="2" align="center"><img src="'.site_url().'assets/logo/logo.jpg" width="80px" /></td>
          <td width="85%" class="company">PT. TALANG SARI LESTARI</td>
        </tr>
        <tr>
          <td class="address">Jalan Perumahan Talang Sari (Kantor Pemasaran) Blok AA No 15A, Kel. Tanah Merah, Kec. Samarinda Utara, Telpon : 0858 4552 0042</td>
        </tr>
        </table>');

        $mpdf->SetHTMLFooter('<div style="border-top: 1px solid #000000; font-size: 9pt; text-align: center; padding-top: 3mm; ">
        <table width="100%">
            <tr>
                <td width="33%">{DATE j F Y H:i:s}</td>
                <td width="33%" align="center">{PAGENO}/{nbpg}</td>
                <td width="33%" style="text-align: right; ">'.get_site('name').'</td>
            </tr>
        </table>
        </div>');
        $pdfFilePath = "cetaktagihan_".time().".pdf";
        $data = array(
            'ttunggakan' =>  $this->Tagihan_model->sum('total_tagihan',array(' tb_tinvoice.no_rumah' => datatagihan($id, 'no_rumah'), 'status_bayar !=' => 'Sudah Bayar', 'jatuhtempo <=' =>date('Y-m').'-15')),
            'record_setting' =>  $this->Setperiode_model->get_by2(array('status' => 'Active'), NULL, NULL, NULL, TRUE),
            'record_tagihan' =>  $this->Tagihan_model->get2($id, TRUE),
            'record_detail' => $this->Tagihandetail_model->get_by2(array("id_tagihan" => $id),"id_tagihandetail"),
            'record_tunggakan' => $this->Tagihan_model->get_by2(array(' tb_tinvoice.no_rumah' => datatagihan($id, 'no_rumah'), 'status_bayar !=' => 'Sudah Bayar', 'jatuhtempo <=' =>date('Y-m').'-15'), "id_tagihan")
        );
        $data['sign'] = get_user_info('nama');
        $data['laporan'] = 'Tagihan Air';
        $this->site->view('laporan/tagihan/tagihan', $data, true);
        $html = $this->output->get_output();                      
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);
        $mpdf->Output($pdfFilePath, "I");
        exit;
    }

    public function cetak_bulk() { 

    }

    public function tagihan_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        ini_set('max_execution_time', 300);
        $this->_validate();
        $bulan     = $this->input->post('bulan');
        $cluster   = $this->input->post('cluster');
        $meter     = $this->input->post('meter');
        $norumah   = $this->input->post('rumah');
        $m3old     = $this->input->post('M3Old');
        $m3now     = $this->input->post('M3Now');
        $sisapulsa = $this->input->post('pulsa');
        
        $x = explode(' ',$bulan);
        $administrasi = biaya("2".substr($x[1],2,2));
        $batas = batasakhir();
        $periode = periode(date($x[1]."-".getIndexOfMonth($x[0])."-25")); 
        $tagihanair = array();
        foreach($m3now as $i=>$val) {
            unset($hm3, $hharga, $hket);
            $urut = datarumah($norumah[$i], 'urut');
            $blok = datarumah($norumah[$i], 'id_blok');
            if ($this->Setharga_model->count(array('id_cluster' => $urut)) > 0) {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $urut),"urutan");
            } else if ($this->Setharga_model->count(array('id_cluster' => $blok)) > 0) {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $blok),"urutan");
            } else {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $cluster),"urutan");
            }       
            foreach ($list as $harga) {
                $hm3[] = $harga['m3'];
                $hharga[] = $harga['harga'];
                $hket[] = $harga['ket'];
            }
    
            if (!empty($m3now[$i])) {
                $mg3now = round($m3now[$i]);
                $mg3old = round($m3old[$i]);
                $pemakaian = $mg3now - $mg3old;
                $xpakai = $pemakaian;
                $y=0;
                $totagihan=0;
                unset($tagihanair);
                foreach ($hm3 as $j=>$val) {
                    if ($xpakai > 0) {
                        if ($hm3[$j] == "*") {
                            $tharga[$y] = $hharga[$j];
                            $tket[$y] = $hket[$j];
                            $spk[$y] = $xpakai;
                            $xpakai -= $spk[$y];
                            $tagihanair[$y] = $spk[$y] * $tharga[$y];                            
                            $y++;
                        } else {
                            if ($xpakai >= $hm3[$j]) {
                                $tharga[$y] = $hharga[$j];
                                $tket[$y] = $hket[$j];
                                $spk[$y] = $hm3[$j];
                                $xpakai -= $spk[$y];
                                $tagihanair[$y] = $spk[$y] * $tharga[$y];                            
                                $y++;
                            } else {
                                $tharga[$y] = $hharga[$j];
                                $tket[$y] = $hket[$j];
                                $spk[$y] = $xpakai;
                                $xpakai -= $spk[$y];
                                $tagihanair[$y] = $spk[$y] * $tharga[$y];                          
                                $y++;
                            }
                        } 
                    }
                }

                $totagihan = array_sum($tagihanair);
                $pajak = biaya("4".substr($x[1],2,2));
                $nilai_pajak = $totagihan * $pajak / 100; 
                $btagihan = ($totagihan + $administrasi + $nilai_pajak) / 10000;
                $potong = potongan($btagihan, $sisapulsa[$i]);
                $sisa = sisa($btagihan, $sisapulsa[$i]);
                $grandtagihan = ($btagihan * 10000) - $potong;
                $status = status_bayar($grandtagihan);

                $kode = $this->Tagihan_model->kodeauto($x[1].getIndexOfMonth($x[0]),11);
                $data = array(
                        'id_tagihan' => $kode,
                        'no_tagihan' => "INV/WTP/".$x[1]."/".getIndexOfMonth($x[0])."/".substr($kode, -4),
                        'periode' => $periode,
                        'tgl_cetak' => tanggal_pemakaian(date($x[1]."-".getIndexOfMonth($x[0])."-25")),
                        'bulan' => substr($x[0],0,3)." ".substr($x[1],2,2),
                        'no_rumah' => $norumah[$i],
                        'no_seriemeteran' => $meter[$i],
                        'M3Now' => $mg3now,
                        'M3Last' => $mg3old,
                        'pakai' => $pemakaian,
                        'biaya_adm' => $administrasi,
                        'nilai_pakai' => $totagihan,
                        'potongan' => $potong,
                        'pajak' => $nilai_pajak,
                        'total_tagihan' => $grandtagihan, 
                        'status_bayar' => $status, 
                        'jatuhtempo'=> date($x[1]."-".getIndexOfMonth($x[0])."-".$batas),
                        //'users'=> get_user_info('ID'),
                        //'created'=>date('Y-m-d H:i:s')
                );
                $insert = $this->Tagihan_model->insert($data);
                foreach ($tagihanair as $z=>$val) {
                    $kode2 = $this->Tagihandetail_model->kodeauto($kode,13);
                    $this->SimpanDetail($kode2, $kode, $spk[$z], $tharga[$z], $tagihanair[$z], $tket[$z]);
                }
                $data4 = array(
                    'sisa_pulsa' => $sisa,
                    'angka_meteran'=> datatagihan2(array('tb_tinvoice.no_rumah' => $norumah[$i])),
                );
                $this->Rumah_model->update($data4,$norumah[$i]);
            }
        }
        datalogs(8, 'Menambahkan Data', 'Data Tagihan Bulan : '.$this->input->post('bulan'),json_encode($norumah));        
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function tagihan_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Tagihan_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function tagihan_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->_editvalidate();
            $kode      = $this->input->post('id');
            $norumah   = $this->input->post('norumah');
            $mold     = $this->input->post('MOld');
            $mnow     = $this->input->post('MNow');
            $sisapulsa = datarumah($norumah, "sisa_pulsa") + $this->input->post('potongan');

            $administrasi = biaya("2".substr(date("Y"),2,2));        
            $urut = datarumah($norumah, 'urut');
            $blok = datarumah($norumah, 'id_blok');
            $cluster = datarumah($norumah, "id_cluster");
            if ($this->Setharga_model->count(array('id_cluster' => $urut)) > 0) {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $urut),"urutan");
            } else if ($this->Setharga_model->count(array('id_cluster' => $blok)) > 0) {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $blok),"urutan");
            } else {
              $list = $this->Setharga_model->get_by2(array("tb_settingharga.id_cluster" => $cluster),"urutan");
            }       
            foreach ($list as $harga) {
                $hm3[] = $harga['m3'];
                $hharga[] = $harga['harga'];
                $hket[] = $harga['ket'];
            }
            $pemakaian = $mnow - $mold;
            $xpakai = $pemakaian;
            $y=0;
            $totagihan = 0;
            $this->Tagihandetail_model->delete_by(array('id_tagihan' => $kode));
            foreach ($hm3 as $j=>$val) {
                if ($xpakai > 0) {
                    if ($hm3[$j] == "*") {
                        $tharga[$y] = $hharga[$j];
                        $tket[$y] = $hket[$j];
                        $spk[$y] = $xpakai;
                        $xpakai -= $spk[$y];
                        $tagihanair[$y] = $spk[$y] * $tharga[$y];                            
                        $y++;
                    } else {
                        if ($xpakai >= $hm3[$j]) {
                            $tharga[$y] = $hharga[$j];
                            $tket[$y] = $hket[$j];
                            $spk[$y] = $hm3[$j];
                            $xpakai -= $spk[$y];
                            $tagihanair[$y] = $spk[$y] * $tharga[$y];                            
                            $y++;
                        } else {
                            $tharga[$y] = $hharga[$j];
                            $tket[$y] = $hket[$j];
                            $spk[$y] = $xpakai;
                            $xpakai -= $spk[$y];
                            $tagihanair[$y] = $spk[$y] * $tharga[$y];                            
                            $y++;
                        }
                    } 
                }
            }
            $totagihan = array_sum($tagihanair);
            $pajak = biaya("4".substr(date("Y"),2,2));
            $nilai_pajak = $totagihan * $pajak / 100; 
            $btagihan = ($totagihan + $administrasi + $nilai_pajak) / 10000;
            $btagihan = ($totagihan + $administrasi) / 10000;
            $potong = potongan($btagihan, $sisapulsa);
            $sisa = sisa($btagihan, $sisapulsa);
            $grandtagihan = ($btagihan * 10000) - $potong;
            $status = status_bayar($grandtagihan);
            $data3 = array(
                    'M3Now' => $mnow,
                    'M3Last' => $mold,
                    'pakai' => $pemakaian,
                    'biaya_adm' => $administrasi,
                    'nilai_pakai' => $totagihan,
                    'potongan' => $potong,
                    'pajak' => $nilai_pajak,
                    'total_tagihan' => $grandtagihan, 
                    'status_bayar' => $status, 
                    //'users'=> get_user_info('ID'),
                    //'edited'=>date('Y-m-d H:i:s')
            );
            $this->Tagihan_model->update($data3,$kode);
            foreach ($tagihanair as $z=>$val) {
                $kode2 = $this->Tagihandetail_model->kodeauto($kode,13);
                $this->SimpanDetail($kode2, $kode, $spk[$z], $tharga[$z], $tagihanair[$z], $tket[$z]);
            }
            $data4 = array(
                'sisa_pulsa' => $sisa,
                'angka_meteran'=> datatagihan2(array('tb_tinvoice.no_rumah' => $norumah)),
            );
            $this->Rumah_model->update($data4,$norumah);
            datalogs(8, 'Merubah Data', 'Data Tagihan : '.$kode,json_encode($data3));
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function tagihan_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $norumah = datatagihan($id, 'no_rumah');
            $sisapulsa = datarumah($norumah, 'sisa_pulsa');
            $sisa = (datatagihan($id,'potongan') / 10000) + $sisapulsa;
            $data4 = array(
                'sisa_pulsa' => $sisa,
                'angka_meteran'=> datatagihan2(array('tb_tinvoice.no_rumah' => $norumah), 'M3Last'),
            );
            $this->Rumah_model->update($data4, $norumah);
            $this->Tagihan_model->delete($id);
            datalogs(8, 'Menghapus Data', 'Menghapus Data Tagihan : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function tagihan_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(8, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Tagihan',json_encode($list_id));
        foreach ($list_id as $id) {
            $norumah = datatagihan($id, 'no_rumah');
            $sisapulsa = datarumah($norumah, 'sisa_pulsa');
            $sisa = (datatagihan($id, 'potongan') / 10000) + $sisapulsa;
            $data4 = array(
                'sisa_pulsa' => $sisa,
                'angka_meteran'=> datatagihan2(array('tb_tinvoice.no_rumah' => $norumah), 'M3Last'),
            );
            $this->Tagihan_model->delete($id);
            $this->Rumah_model->update($data4, $norumah);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function SimpanDetail($kode, $id, $pakai, $harga, $nominal, $ket) {
        $data2 = array(
                'id_tagihandetail' => $kode,
                'id_tagihan' => $id,
                'pemakaian' => $pakai,
                'harga' => $harga,
                'nominalpakai' => $nominal,
                'ket' => $ket,
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $in = $this->Tagihandetail_model->insert($data2);

    }

    private function _validate() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'bulan' => array(
                'field' => 'bulan', 
                'label' => 'Bulan tagihan', 
                'rules' => 'trim|required|xss_clean',
            ),
            'cluster' => array(
                'field' => 'cluster', 
                'label' => 'Cluster Perumahan', 
                'rules' => 'trim|required|xss_clean',
            )

        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  

        $M3Now = $this->input->post('M3Now');
        $M3Old = $this->input->post('M3Old');
        foreach($M3Now as $ind=>$val) {
            $jum  = $M3Now[$ind];
            $min  = $M3Old[$ind];
            $this->form_validation->set_rules("M3Now[".$ind."]", "Saat Ini", "trim|xss_clean|greater_than_equal_to[".$min."]");
        }
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('bulan'))) {
                $data['inputerror'][] = 'bulan';
                $data['error_string'][] = form_error('bulan');
            }
            if(!empty(form_error('cluster'))) {
                $data['inputerror'][] = 'cluster';
                $data['error_string'][] = form_error('cluster');
            }
            for($i = 0; $i < count($M3Now); $i++) {
                if(!empty(form_error("M3Now[".$i."]"))) {
                    $data['inputerror'][] = "M3Now[".$i."]";
                    $data['error_string'][] = form_error("M3Now[".$i."]");
                }
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    private function _editvalidate() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'MNow' => array(
                'field' => 'M3Now', 
                'label' => 'Saat Ini', 
                'rules' => 'trim|xss_clean|greater_than_equal_to[1]',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('MNow'))) {
                $data['inputerror'][] = 'MNow';
                $data['error_string'][] = form_error('MNow');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}