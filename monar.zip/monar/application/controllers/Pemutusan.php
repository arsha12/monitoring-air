<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemutusan extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Pemutusan_model','Rumah_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/pemutusan', $data);
    }
    
   public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'record_rumah' => $this->Rumah_model->get_by(array('status_meter' => 'Aktif'), 'urut'),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pemutusan_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = $this->Rumah_model->get_by(array("no_rumah" => $id), NULL, 1, NULL, TRUE);
            echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pemutusan_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Pemutusan_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $Pemutusan) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($Pemutusan->id_pemutusan).'"> '.$no;
            $row[] = tampil(tgl_indo2($Pemutusan->tanggal_pemutusan));
            $row[] = tampil($Pemutusan->no_rumah);
            $row[] = tampil($Pemutusan->nm_customer);
            $row[] = tampil($Pemutusan->alasan);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" titlindoit" onclick="edit_data('."'".$Pemutusan->id_pemutusan."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$Pemutusan->id_pemutusan."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Pemutusan_model->count_all(),
                        "recordsFiltered" => $this->Pemutusan_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pemutusan_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("");
        $tg = date("Y");
        $kode = $this->Pemutusan_model->kodeauto("P".$tg,9);
        $data = array(
                'id_pemutusan' => $kode,
                'tanggal_pemutusan' => date('Y-m-d'),
                'no_rumah' => $this->input->post('norumah'),
                'alasan' => $this->input->post('alasan'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Pemutusan_model->insert($data);
        datalogs(10, 'Menambahkan Data', 'Data Pemutusan Meteran : '.$this->input->post('norumah'),json_encode($data));        
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pemutusan_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Pemutusan_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pemutusan_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate("");
        $data = array(
                'alasan' => $this->input->post('alasan'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Pemutusan_model->update($data,$this->input->post('id'));
        datalogs(10, 'Merubah Data', 'Data Pemutusan Meteran : '.$this->input->post($id),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pemutusan_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            datalogs(10, 'Menghapus Data', 'Menghapus Data Pemutusan Meteran : '.$id,$id);
            $this->Pemutusan_model->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pemutusan_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(10, 'Menghapus Data', 'Menghapus '.count($list_id).' Data Pemutusan Meteran',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Pemutusan_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate($Meteran) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $rules = array(
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean',
            ),
            'alasan' => array(
                'field' => 'alasan', 
                'label' => 'Alasan Pemutusan', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }
            if(!empty(form_error('alasan'))) {
                $data['inputerror'][] = 'alasan';
                $data['error_string'][] = form_error('alasan');
            }

            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }
}