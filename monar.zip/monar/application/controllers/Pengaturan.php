<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengaturan extends Backend_Controller {

	public function __construct(){
		parent::__construct();
        $this->load->model(array('Cluster_model','Blok_model','Rumah_model','Setharga_model','Sethargablok_model','Sethargarumah_model','Setlain_model','Setperiode_model'));
	}

    public function index(){
        $data = array();
        $this->site->view('module/pengaturan', $data);
    }
    
    public function ambil_data(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
               'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
               'record_blok' => $this->Blok_model->get(NULL, NULL, 'id_blok'),
               'record_rumah' => $this->Rumah_model->get(NULL, NULL, 'urut'),
             );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pengaturan_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'urut' => $this->Setharga_model->max('urutan', array('id_cluster' => $id)),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pengaturan_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Setharga_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $setharga) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($setharga->id_setharga).'"> '.$no;
            $row[] = tampil($setharga->m3);
            $row[] = '<div align="right">'.tampil(curen($setharga->harga)).'</div>';
            $row[] = $setharga->ket;
            $row[] = tampil($setharga->urutan);
            $row[] = tampil($setharga->cluster);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Setharga_model->count_all(),
                        "recordsFiltered" => $this->Setharga_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }

    }

    public function pengaturan_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate();
        $kode = $this->Setharga_model->kodeauto("1".$this->input->post('cluster'),9);
        $data = array(
                'id_setharga' => $kode,
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket'),
                'urutan' => $this->input->post('urutan'),
                'id_cluster' => $this->input->post('cluster'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Setharga_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Harga : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengaturan_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Setharga_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengaturan_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validate();
        $data = array(
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket'),
                'urutan' => $this->input->post('urutan'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Setharga_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Harga : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pengaturan_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Setharga_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Harga : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pengaturan_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Harga',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Setharga_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validate() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'm3' => array(
                'field' => 'm3', 
                'label' => 'Pemakaian M3', 
                'rules' => 'trim|required|xss_clean',
            ),
            'harga' => array(
                'field' => 'harga', 
                'label' => 'Harga Air', 
                'rules' => 'trim|required|xss_clean',
            ),
            'urutan' => array(
                'field' => 'urutan', 
                'label' => 'Urutan', 
                'rules' => 'trim|required|xss_clean',
            ),
            'cluster' => array(
                'field' => 'cluster', 
                'label' => 'Cluster Perumahan', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('m3'))) {
                $data['inputerror'][] = 'm3';
                $data['error_string'][] = form_error('m3');
            }
            if(!empty(form_error('harga'))) {
                $data['inputerror'][] = 'harga';
                $data['error_string'][] = form_error('harga');
            }
            if(!empty(form_error('urutan'))) {
                $data['inputerror'][] = 'urutan';
                $data['error_string'][] = form_error('urutan');
            }
            if(!empty(form_error('cluster'))) {
                $data['inputerror'][] = 'cluster';
                $data['error_string'][] = form_error('cluster');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    public function hargablok_data($id){
            $data = array(
                'urut' => $this->Sethargablok_model->max('urutan', array('id_cluster' => $id)),
            );
            echo json_encode($data);   
    }

    public function hargablok_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Sethargablok_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $setharga) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($setharga->id_setharga).'"> '.$no;
            $row[] = tampil($setharga->m3);
            $row[] = '<div align="right">'.tampil(curen($setharga->harga)).'</div>';
            $row[] = $setharga->ket;
            $row[] = tampil($setharga->urutan);
            $row[] = tampil($setharga->blok);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_hargablok('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_hargablok('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Sethargablok_model->count_all(),
                        "recordsFiltered" => $this->Sethargablok_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }

    }

    public function hargablok_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatehargablok();
        $kode = $this->Sethargablok_model->kodeauto("1".$this->input->post('blok'),11);
        $data = array(
                'id_setharga' => $kode,
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket2'),
                'urutan' => $this->input->post('urutanblok'),
                'id_cluster' => $this->input->post('blok'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Sethargablok_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Harga per Blok : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargablok_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Sethargablok_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargablok_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatehargablok();
        $data = array(
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket2'),
                'urutan' => $this->input->post('urutanblok'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Sethargablok_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Harga per Blok : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargablok_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Sethargablok_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Harga per Blok : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function hargablok_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Harga per Blok',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Sethargablok_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validatehargablok() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'm3' => array(
                'field' => 'm3', 
                'label' => 'Pemakaian M3', 
                'rules' => 'trim|required|xss_clean',
            ),
            'harga' => array(
                'field' => 'harga', 
                'label' => 'Harga Air', 
                'rules' => 'trim|required|xss_clean',
            ),
            'urutanblok' => array(
                'field' => 'urutanblok', 
                'label' => 'Urutan', 
                'rules' => 'trim|required|xss_clean',
            ),
            'blok' => array(
                'field' => 'blok', 
                'label' => 'Blok Perumahan', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('m3'))) {
                $data['inputerror'][] = 'm3';
                $data['error_string'][] = form_error('m3');
            }
            if(!empty(form_error('harga'))) {
                $data['inputerror'][] = 'harga';
                $data['error_string'][] = form_error('harga');
            }
            if(!empty(form_error('urutanblok'))) {
                $data['inputerror'][] = 'urutanblok';
                $data['error_string'][] = form_error('urutanblok');
            }
            if(!empty(form_error('blok'))) {
                $data['inputerror'][] = 'blok';
                $data['error_string'][] = form_error('blok');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    public function hargarumah_data($id){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $data = array(
                'urut' => $this->Sethargarumah_model->max('urutan', array('id_cluster' => $id)),
            );
            echo json_encode($data);   
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function hargarumah_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');

        $list = $this->Sethargarumah_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $setharga) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check" value="'.tampil($setharga->id_setharga).'"> '.$no;
            $row[] = tampil($setharga->m3);
            $row[] = '<div align="right">'.tampil(curen($setharga->harga)).'</div>';
            $row[] = $setharga->ket;
            $row[] = tampil($setharga->urutan);
            $row[] = tampil($setharga->no_rumah);
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_hargarumah('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_hargarumah('."'".$setharga->id_setharga."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Sethargarumah_model->count_all(),
            "recordsFiltered" => $this->Sethargarumah_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        }

    }

    public function hargarumah_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatehargarumah();
        $kode = $this->Sethargarumah_model->kodeauto("1".$this->input->post('norumah'),15);
        $data = array(
                'id_setharga' => $kode,
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket3'),
                'urutan' => $this->input->post('urutanrumah'),
                'id_cluster' => $this->input->post('norumah'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $insert = $this->Sethargarumah_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Harga per Pelanggan : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargarumah_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Sethargarumah_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargarumah_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatehargarumah();
        $data = array(
                'm3' => $this->input->post('m3'),
                'harga' => angka($this->input->post('harga')),
                'ket' => $this->input->post('ket3'),
                'urutan' => $this->input->post('urutanrumah'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Sethargarumah_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Harga per Pelanggan : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function hargarumah_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Sethargarumah_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Harga per Pelanggan : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function hargarumah_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Harga per Pelanggan',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Sethargarumah_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validatehargarumah() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'm3' => array(
                'field' => 'm3', 
                'label' => 'Pemakaian M3', 
                'rules' => 'trim|required|xss_clean',
            ),
            'harga' => array(
                'field' => 'harga', 
                'label' => 'Harga Air', 
                'rules' => 'trim|required|xss_clean',
            ),
            'urutanrumah' => array(
                'field' => 'urutanrumah', 
                'label' => 'Urutan', 
                'rules' => 'trim|required|xss_clean',
            ),
            'norumah' => array(
                'field' => 'norumah', 
                'label' => 'Nomor Rumah', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('m3'))) {
                $data['inputerror'][] = 'm3';
                $data['error_string'][] = form_error('m3');
            }
            if(!empty(form_error('harga'))) {
                $data['inputerror'][] = 'harga';
                $data['error_string'][] = form_error('harga');
            }
            if(!empty(form_error('urutanrumah'))) {
                $data['inputerror'][] = 'urutanrumah';
                $data['error_string'][] = form_error('urutanrumah');
            }
            if(!empty(form_error('norumah'))) {
                $data['inputerror'][] = 'norumah';
                $data['error_string'][] = form_error('norumah');
            }
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }


    public function admin_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $seleksi = array('settinglain.setlain'=> 'Biaya Admin');        
        $list = $this->Setlain_model->get_datatables($seleksi);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $admin) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check-admin" value="'.tampil($admin->id_setlain).'"> '.$no;
            $row[] = tampil($admin->tahun);
            $row[] = '<div align="right">'.tampil(curen($admin->harga)).'</div>';

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" title="Edit" onclick="edit_admin('."'".$admin->id_setlain."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_admin('."'".$admin->id_setlain."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Setlain_model->count_all($seleksi),
                        "recordsFiltered" => $this->Setlain_model->count_filtered($seleksi),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function admin_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validateadmin();
        $kode = "2".substr($this->input->post('tahun'),2,2);
        $data = array(
                'id_setlain' => $kode,
                'setlain' => "Biaya Admin",
                'deskripsi' => "Biaya Adminsitrasi Tahun ".$this->input->post('tahun'),
                'harga' => angka($this->input->post('admin')),
                'tahun' => $this->input->post('tahun'),
                'jenis' => "Flat",
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Biaya Adminsitrasi : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function admin_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Setlain_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function admin_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validateadmin();
        $data = array(
                'harga' => angka($this->input->post('admin')),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Biaya Adminsitrasi : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function admin_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Setlain_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Biaya Adminsitrasi : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function admin_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Biaya Adminsitrasi',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Setlain_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validateadmin() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'tahun' => array(
                'field' => 'tahun', 
                'label' => 'Tahun', 
                'rules' => 'trim|required|xss_clean',
            ),
            'admin' => array(
                'field' => 'admin', 
                'label' => 'Biaya Adminsitrasi', 
                'rules' => 'trim|required|xss_clean',
            )
        );  
        $pesan = $this->Setlain_model->rulepesan;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        $this->form_validation->set_message($pesan);
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('tahun'))) {
                $data['inputerror'][] = 'tahun';
                $data['error_string'][] = form_error(tahun);
            }
            if(!empty(form_error('admin'))) {
                $data['inputerror'][] = 'admin';
                $data['error_string'][] = form_error('admin');
            }            
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    public function pajak_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $seleksi = array('settinglain.setlain'=> 'Pajak');        
        $list = $this->Setlain_model->get_datatables($seleksi);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $pajak) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check-pajak" value="'.tampil($pajak->id_setlain).'"> '.$no;
            $row[] = tampil($pajak->tahun);
            $row[] = '<div align="right">'.tampil(curen($pajak->harga)).'</div>';
            $row[] = tampil($pajak->jenis);

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_pajak('."'".$pajak->id_setlain."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_pajak('."'".$pajak->id_setlain."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Setlain_model->count_all($seleksi),
                        "recordsFiltered" => $this->Setlain_model->count_filtered($seleksi),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pajak_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatepajak();
        $kode = "4".substr($this->input->post('tahun'),2,2);
        $data = array(
                'id_setlain' => $kode,
                'setlain' => "Pajak",
                'deskripsi' => "Pajak Tahun ".$this->input->post('tahun'),
                'harga' => $this->input->post('pajak'),
                'tahun' => $this->input->post('tahun'),
                'jenis' => "Persen",
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Pajak : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pajak_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Setlain_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pajak_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validatepajak();
        $data = array(
                'harga' => $this->input->post('pajak'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Pajak : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function pajak_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Setlain_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Pajak : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function pajak_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Pajak',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Setlain_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validatepajak() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'tahun' => array(
                'field' => 'tahun', 
                'label' => 'Tahun', 
                'rules' => 'trim|required|xss_clean',
            ),
            'pajak' => array(
                'field' => 'pajak', 
                'label' => 'Pajak', 
                'rules' => 'trim|required|numeric|max_length[3]|greater_than_equal_to[-100]|less_than_equal_to[200]|xss_clean',
            )
        );  
        $pesan = $this->Setlain_model->rulepesan;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        $this->form_validation->set_message($pesan);
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('tahun'))) {
                $data['inputerror'][] = 'tahun';
                $data['error_string'][] = form_error(tahun);
            }
            if(!empty(form_error('pajak'))) {
                $data['inputerror'][] = 'pajak';
                $data['error_string'][] = form_error('pajak');
            }            
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    public function denda_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $seleksi = array('settinglain.setlain'=> 'Denda');        
        $list = $this->Setlain_model->get_datatables($seleksi);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $denda) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check-denda" value="'.tampil($denda->id_setlain).'"> '.$no;
            $row[] = tampil($denda->tahun);
            $row[] = '<div align="right">'.tampil(curen($denda->harga)).'</div>';
            $row[] = tampil($denda->jenis);
            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_denda('."'".$denda->id_setlain."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_denda('."'".$denda->id_setlain."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Setlain_model->count_all($seleksi),
                        "recordsFiltered" => $this->Setlain_model->count_filtered($seleksi),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function denda_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('jenis') == "Persen") { $xv = "|max_length[3]|greater_than_equal_to[0]|less_than_equal_to[200]";} else { $xv = ""; }
        $this->_validatedenda($xv);
        $kode = "4".substr($this->input->post('tahun'),2,2);
        $data = array(
                'id_setlain' => $kode,
                'setlain' => "Denda",
                'deskripsi' => "Denda Tahun ".$this->input->post('tahun'),
                'harga' => angka($this->input->post('denda')),
                'tahun' => $this->input->post('tahun'),
                'jenis' => $this->input->post('jenis'),
                'kondisi' => $this->input->post('kondisi'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Denda : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function denda_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Setlain_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function denda_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        if ($this->input->post('jenis') == "Persen") { $xv = "|max_length[3]|greater_than_equal_to[0]|less_than_equal_to[200]";} else { $xv = ""; }
        $this->_validatedenda($xv);
        $data = array(
                'kondisi' => $this->input->post('kondisi'),
                'jenis' => $this->input->post('jenis'),
                'harga' => angka($this->input->post('denda')),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Setlain_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Denda : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function denda_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Setlain_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Denda : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function denda_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Denda',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Setlain_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validatedenda($kondisi) {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
        $rules = array(
            'tahun' => array(
                'field' => 'tahun', 
                'label' => 'Tahun', 
                'rules' => 'trim|required|xss_clean',
            ),
            'denda' => array(
                'field' => 'denda', 
                'label' => 'Denda Keterlambatan', 
                'rules' => 'trim|required|xss_clean'.$kondisi,
            )
        );  
        $pesan = $this->Setlain_model->rulepesan;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        $this->form_validation->set_message($pesan);
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('tahun'))) {
                $data['inputerror'][] = 'tahun';
                $data['error_string'][] = form_error(tahun);
            }
            if(!empty(form_error('denda'))) {
                $data['inputerror'][] = 'denda';
                $data['error_string'][] = form_error('denda');
            }            
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

    public function periode_list() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->load->helper('url');
        $list = $this->Setperiode_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $periode) {
            $no++;
            $row = array();
            $row[] = '<input type="checkbox" class="data-check-periode" value="'.tampil($periode->id_setperiode).'"> '.$no;
            $row[] = tampil($periode->tgl_awal);
            $row[] = tampil($periode->tgl_akhir);
            $row[] = tampil($periode->status);
            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_periode('."'".$periode->id_setperiode."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_periode('."'".$periode->id_setperiode."'".')"><i class="glyphicon glyphicon-trash"></i></a>';
        
            $data[] = $row;
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Setperiode_model->count_all(),
                        "recordsFiltered" => $this->Setperiode_model->count_filtered(),
                        "data" => $data,
        );
        echo json_encode($output);
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function periode_add() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validateperiode();
        $kode = $this->Setperiode_model->kodeauto("5",5);
        $data = array(
                'id_setperiode' => $kode,
                'tgl_awal' => $this->input->post('awal'),
                'tgl_akhir' => $this->input->post('akhir'),
                //'users'=> get_user_info('ID'),
                //'created'=>date('Y-m-d H:i:s')
        );
        $this->Setperiode_model->insert($data);
        datalogs(0, 'Menambahkan Data', 'Pengaturan Periode : '.$kode,json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function periode_edit($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $data = $this->Setperiode_model->get2($id);
        echo json_encode($data);
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function periode_update() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $this->_validateperiode();
        $data = array(
                'tgl_awal' => $this->input->post('awal'),
                'tgl_akhir' => $this->input->post('akhir'),
                //'users'=> get_user_info('ID'),
                //'edited'=>date('Y-m-d H:i:s')
        );
        $this->Setperiode_model->update($data,$this->input->post('id'));
        datalogs(0, 'Mengubah Data', 'Pengaturan Periode : '.$this->input->post('id'),json_encode($data));
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        }
    }

    public function periode_delete($id) {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $this->Setperiode_model->delete($id);
            datalogs(0, 'Menghapus Data', 'Pengaturan Periode : '.$id,$id);
            echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    public function periode_bulk_delete() {
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
        $list_id = $this->input->post('id');
        datalogs(0, 'Menghapus Data', 'Menghapus '.count($list_id).' Pengaturan Periode',json_encode($list_id));
        foreach ($list_id as $id) {
            $this->Setperiode_model->delete($id);
        }
        echo json_encode(array("status" => TRUE));
        } else {
            redirect(set_url('dashboard'));
        } 
    }

    private function _validateperiode() {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;

        $tgl = $this->input->post('awal');

        $rules = array(
            'awal' => array(
                'field' => 'awal', 
                'label' => 'Awal Pembayaran', 
                'rules' => 'trim|required|numeric|greater_than_equal_to[1]|xss_clean',
            ),
            'akhir' => array(
                'field' => 'akhir', 
                'label' => 'Batas Akhir Pembayaran', 
                'rules' => 'trim|required|numeric|greater_than['.$tgl.']|less_than_equal_to[31]|xss_clean',
            )
        );  
        $pesan = $this->Setperiode_model->rulepesan;
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules($rules);  
        $this->form_validation->set_message($pesan);
        if ($this->form_validation->run() == FALSE){    
            if(!empty(form_error('awal'))) {
                $data['inputerror'][] = 'awal';
                $data['error_string'][] = form_error('awal');
            }
            if(!empty(form_error('akhir'))) {
                $data['inputerror'][] = 'akhir';
                $data['error_string'][] = form_error('akhir');
            }            
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
    }

}