<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporansuratpemberitahuan extends Backend_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model(array('Surat_model','Cluster_model'));
    }

    public function index(){
        $data = array();
        $this->site->view('laporan/filterlaporansuratpemberitahuan', $data);
    }

    public function ambil_filter(){
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            echo json_encode(array(
                'record_cluster' => $this->Cluster_model->get(NULL, NULL, 'cluster'),
            ));
        } else {
            redirect(set_url('dashboard'));
        } 
    }
 
    public function bulan() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('suratcluster');
        $bulan = $this->input->post('suratbulan');
        $x = explode(' ',$bulan);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Bulan : '.$bulan;
        $where['month(tgl_surat)'] = getIndexOfMonth($x[0]);
        $where['year(tgl_surat)'] = $x[1];
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $data['record_surat'] = $this->Surat_model->get_by2($where, "id_surat");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporansuratbulan_".time().".pdf";
        laporanpdf('laporan/suratpemberitahuan/daftar', $data, $set, "Laporan Surat Pemberitahuan Per Bulan", $pdfFilePath);
    }

    public function periode() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('suratcluster');
        $periode = $this->input->post('suratperiode');
        $x = explode(' - ',$periode);
        $y1 = explode('/',$x[0]); 
        $y2 = explode('/',$x[1]);
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $per = $y1[0].' '.getNameOfMonth($y1[1]).' '.$y1[2].' - '.$y2[0].' '.getNameOfMonth($y2[1]).' '.$y2[2];
        $fill[0] ='Bulan : '.$per;
        $where = array();
        if (!empty($cluster)) {
            $ldata = $this->Cluster_model->view($cluster);
            $where['m3blok.id_cluster'] = $cluster;
            $fill[1] ='Cluster : '.$ldata->cluster;
        }
        $where['tgl_surat >='] = date($y1[2]."/".$y1[1]."/".$y1[0]);
        $where['tgl_surat <='] = date($y2[2]."/".$y2[1]."/".$y2[0]);
        $data['record_surat'] = $this->Surat_model->get_by2($where, "id_surat");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporansuratperiode_".time().".pdf";
        laporanpdf('laporan/suratpemberitahuan/daftar', $data, $set, "Laporan Surat Pemberitahuan Periode", $pdfFilePath);
    }

    public function tahun() { 
        //'format' => [190, 236],
        $cluster = $this->input->post('suratcluster');
        $tahun = $this->input->post('surattahun');
        $set = ['mode' => 'utf-8', 'format' => 'Folio', 'orientation' => 'P','setAutoTopMargin' => 'stretch','autoMarginPadding' => 1];
        $fill[0] ='Tahun : '.$tahun;
        $where = 'WHERE year(tgl_surat) ='.$tahun;
        $data['record_surat'] = $this->Surat_model->getquery2("SELECT DISTINCT tgl_surat, bentuk, COUNT(id_surat) as jumlah FROM tb_tsurat ".$where." GROUP BY MONTH(tgl_surat), bentuk");
        $data['filter'] = cekfilter($fill);
        $pdfFilePath = "laporansurattahun_".time().".pdf";
        laporanpdf('laporan/suratpemberitahuan/tahun', $data, $set, "Laporan Surat Pemberitahuan Per Tahun", $pdfFilePath);
    }
}