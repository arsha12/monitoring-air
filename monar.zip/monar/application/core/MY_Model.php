<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model{
	protected $_table_name;
	protected $_tquery;
	protected $_tablejoin_name;
	protected $_primaryjoin_key;
	protected $_tablejoin2_name;
	protected $_primaryjoin2_key;
	protected $_tablejoin3_name;
	protected $_primaryjoin3_key;
	protected $_tablejoin_name2;
	protected $_tablejoin2_name2;
	protected $_tablejoin3_name2;
	protected $_join;
	protected $_join2;
	protected $_join3;
	protected $_order;
	protected $_column_order;
	protected $_column_search;
	protected $_order_by;
	protected $_order_by_type = 'ASC';
	protected $_primary_filter = 'intval';
	protected $_primary_key;
	public $rules;

	function __construct(){
		parent::__construct();
	}

    public  function kodeauto($inisial, $panjang) {       
		global $SConfig;
		$table = $SConfig->_table_prefix.$this->_table_name;
        $data = $this->db->query("select max(".$this->_primary_key.") as kode from ".$table." where LEFT(".$this->_primary_key.",".strlen($inisial).") = '".$inisial."'");
        $jml = $data->num_rows();
        $rows = $data->row_array();
          if ($jml > 0){
            $ambilkode = substr($rows['kode'], strlen($inisial));
            $kode = (int) $ambilkode;
            $kode = $kode + 1;
          }else{
            $kode = 1;
          }
        $kodebaru = $inisial.str_pad($kode,$panjang-strlen($inisial)-1,"0",STR_PAD_LEFT);
        return $kodebaru;   
    }

    public  function kodeauto2($field, $inisial, $panjang) {       
		global $SConfig;
		$table = $SConfig->_table_prefix.$this->_table_name;
        $data = $this->db->query("select max(".$field.") as kode from ".$table." where LEFT(".$field.",".strlen($inisial).") = '".$inisial."'");
        $jml = $data->num_rows();
        $rows = $data->row_array();
          if ($jml > 0){
            $ambilkode = substr($rows['kode'], strlen($inisial));
            $kode = (int) $ambilkode;
            $kode = $kode + 1;
          }else{
            $kode = 1;
          }
        $kodebaru = $inisial.str_pad($kode,$panjang-strlen($inisial)-1,"0",STR_PAD_LEFT);
        return $kodebaru;   
    }

	private function _get_datatables_query() {
		$this->db->from($this->_table_name);
		if ($this->_tablejoin_name) {
			if ($this->_join) {
			$joinon = $this->_join;
			} else {
			$joinon = $this->_table_name.".".$this->_primaryjoin_key." = ".$this->_tablejoin_name.".".$this->_primaryjoin_key;
			}
			$this->db->join($this->_tablejoin_name, $joinon, 'left');
		} 
		if ($this->_tablejoin2_name) {
			if ($this->_join2) {
			$joinon2 = $this->_join2;
			} else {
			$joinon2 = $this->_table_name.".".$this->_primaryjoin2_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin2_key;
			}
			$this->db->join($this->_tablejoin2_name, $joinon2, 'left');
		} 
		if ($this->_tablejoin3_name) {
			if ($this->_join3) {
			$joinon3 = $this->_join3;
			} else {
			$joinon3 = $this->_table_name.".".$this->_primaryjoin3_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin3_key;
			}
			$this->db->join($this->_tablejoin3_name, $joinon3, 'left');
		} 

		if ($this->_tablejoin_name2) {
			$joinon = $this->_join;
			$this->db->join($this->_tablejoin_name2, $joinon);
		} 
		if ($this->_tablejoin2_name2) {
			$joinon2 = $this->_join2;
			$this->db->join($this->_tablejoin2_name2, $joinon2);
		} 
		if ($this->_tablejoin3_name2) {
			$joinon3 = $this->_join3;
			$this->db->join($this->_tablejoin3_name2, $joinon3);
		} 


		$i = 0;
		foreach ($this->_column_search as $item) {
			if($_POST['search']['value']) {	
				if($i===0) {
					$this->db->group_start(); 
					$this->db->like($item, $_POST['search']['value']);
				} else {
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->_column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}

		
		if(isset($_POST['order'])) {
			$this->db->order_by($this->_column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} else if(isset($this->_order_by)) {
			$this->db->order_by($this->_order_by,$this->_order_by_type);
		}
	}

	function get_datatables($id=NULL) {
		$this->_get_datatables_query();
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		if($id != NULL){
			$this->db->where($id);
		}
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered($id=NULL) {
		$this->_get_datatables_query();
		if($id != NULL){
			$this->db->where($id);
		}
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all($id=NULL) {
		if($id != NULL){
			$this->db->where($id);
		}
		if ($this->_tablejoin_name2) {
			$joinon = $this->_join;
			$this->db->join($this->_tablejoin_name2, $joinon);
		} 
		if ($this->_tablejoin2_name2) {
			$joinon2 = $this->_join2;
			$this->db->join($this->_tablejoin2_name2, $joinon2);
		} 
		if ($this->_tablejoin3_name2) {
			$joinon3 = $this->_join3;
			$this->db->join($this->_tablejoin3_name2, $joinon3);
		} 

		$this->db->from($this->_table_name);
		return $this->db->count_all_results();
	}

	public function insert($data,$batch=FALSE){
		if($batch == TRUE){
			$this->db->insert_batch('{PRE}'.$this->_table_name, $data);
		} else {
			$this->db->set($data);
			$this->db->insert('{PRE}'.$this->_table_name);
			$id = $this->db->insert_id();
			return $id;
		}
	}

	public function update($data,$id){
		$this->db->set($data);
		$this->db->where($this->_primary_key,$id);
		$this->db->update('{PRE}'.$this->_table_name);
	}	

	public function get3($id=NULL,$single=FALSE){
		if($id != NULL){
			$this->db->where($this->_primary_key,$id);
			$method = 'row_array';
		}

		else if($single == TRUE){
			$method = 'row_array';
		}

		else{
			$method = 'result_array';
		}

		if($this->_order_by_type){
			$this->db->order_by($this->_order_by,$this->_order_by_type);
		}
		else{
			$this->db->order_by($this->_order_by);
		}

		return $this->db->get('{PRE}'.$this->_table_name)->$method();
	}

	public function get2($id=NULL,$single=FALSE,$tipe=NULL){
		if($id != NULL){
			$this->db->where($this->_primary_key,$id);
			$method = 'row_array';
		}

		else if($single == TRUE){
			$method = 'row_array';
		}

		else{
			$method = 'result_array';
		}

		if ($this->_tablejoin_name) {
			if ($this->_join) {
			$joinon = $this->_join;
			} else {
			$joinon = $this->_table_name.".".$this->_primaryjoin_key." = ".$this->_tablejoin_name.".".$this->_primaryjoin_key;
			}
			$this->db->join($this->_tablejoin_name, $joinon, 'left');
		} 
		if ($this->_tablejoin2_name) {
			if ($this->_join2) {
			$joinon2 = $this->_join2;
			} else {
			$joinon2 = $this->_table_name.".".$this->_primaryjoin2_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin2_key;
			}
			$this->db->join($this->_tablejoin2_name, $joinon2, 'left');
		} 
		if ($this->_tablejoin3_name) {
			if ($this->_join3) {
			$joinon3 = $this->_join3;
			} else {
			$joinon3 = $this->_table_name.".".$this->_primaryjoin3_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin3_key;
			}
			$this->db->join($this->_tablejoin3_name, $joinon3, 'left');
		} 

		if ($tipe) {
		$this->db->order_by($tipe);
		} else {			
			if($this->_order_by_type){
				$this->db->order_by($this->_order_by,$this->_order_by_type);
			}else{
				$this->db->order_by($this->_order_by);
			}
		}
		return $this->db->get('{PRE}'.$this->_table_name)->$method();
	}

	public function get_by2($where = NULL,$tipe=NULL, $limit = NULL, $offset = NULL, $single = FALSE, $select = NULL){
		if($select != NULL){
			$this->db->select($select);
		}

		if($where){
			$this->db->where($where);
		}

		if(($limit) && ($offset)){
			$this->db->limit($limit,$offset);
		}
		else if($limit){
			$this->db->limit($limit);
		}

		return $this->get2(NULL,$single,$tipe);
	}

	public function get($id=NULL,$single=FALSE,$tipe=NULL){
		if($id != NULL){
			$this->db->where($this->_primary_key,$id);
			$method = 'row';
		}

		else if($single == TRUE){
			$method = 'row';
		}

		else{
			$method = 'result';
		}

		if ($tipe) {
		$this->db->order_by($tipe);
		} else {			
			if($this->_order_by_type){
				$this->db->order_by($this->_order_by,$this->_order_by_type);
			}else{
				$this->db->order_by($this->_order_by);
			}
		}
		return $this->db->get('{PRE}'.$this->_table_name)->$method();
	}

	public function get_by($where = NULL, $tipe=NULL, $limit = NULL, $offset = NULL, $single = FALSE, $select = NULL){
		if($select != NULL){
			$this->db->select($select);
		}

		if($where){
			$this->db->where($where);
		}

		if(($limit) && ($offset)){
			$this->db->limit($limit,$offset);
		}
		else if($limit){
			$this->db->limit($limit);
		}

		return $this->get(NULL,$single,$tipe);
	}

	public function delete($id){
		/*
		$filter = $this->_primary_filter;
		$id = $filter($id);
		*/
		if(!$id){
			return FALSE;
		}

		$this->db->where($this->_primary_key,$id);
		//$this->db->limit(1);
		$this->db->delete('{PRE}'.$this->_table_name);
	}

	public function delete_by($where = NULL){
		if($where){
			$this->db->where($where);
		}

		$this->db->delete('{PRE}'.$this->_table_name);
	}

	public function view($id){
		if($id != NULL){
			$this->db->where($this->_primary_key,$id);
			$method = 'row';
		}
		return $this->db->get('{PRE}'.$this->_table_name)->$method();
	} 

	public function view_by($where = NULL, $select = NULL){
		if($select != NULL){
			$this->db->select($select);
		}

		if ($this->_tablejoin_name) {
			if ($this->_join) {
			$joinon = $this->_join;
			} else {
			$joinon = $this->_table_name.".".$this->_primaryjoin_key." = ".$this->_tablejoin_name.".".$this->_primaryjoin_key;
			}
			$this->db->join($this->_tablejoin_name, $joinon, 'left');
		} 
		if ($this->_tablejoin2_name) {
			if ($this->_join2) {
			$joinon2 = $this->_join2;
			} else {
			$joinon2 = $this->_table_name.".".$this->_primaryjoin2_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin2_key;
			}
			$this->db->join($this->_tablejoin2_name, $joinon2, 'left');
		} 
		if ($this->_tablejoin3_name) {
			if ($this->_join3) {
			$joinon3 = $this->_join3;
			} else {
			$joinon3 = $this->_table_name.".".$this->_primaryjoin3_key." = ".$this->_tablejoin2_name.".".$this->_primaryjoin3_key;
			}
			$this->db->join($this->_tablejoin3_name, $joinon3, 'left');
		} 


		if($where){
			$this->db->where($where);
		} 

		return $this->get(NULL);
	}

	public function count($where = NULL){
		if($where){
			$this->db->where($where);
		}

		$this->db->from('{PRE}'.$this->_table_name);
		return $this->db->count_all_results();
	}


	public function sum($field = NULL, $where = NULL){
		$this->db->select('SUM('.$field.') as total');
		$this->db->from('{PRE}'.$this->_table_name);
		if($where){
			$this->db->where($where);
		}
		return $this->db->get()->row()->total;
	}

	public function max($field = NULL, $where = NULL){
		$this->db->select('MAX('.$field.') as maks');
		$this->db->from('{PRE}'.$this->_table_name);
		if($where){
			$this->db->where($where);
		}
		return $this->db->get()->row()->maks;
	}

	public function getquery($query=NULL,$single=FALSE){
		if($single == TRUE){
			$method = 'row';
		} else {
			$method = 'result';
		}

		return $this->db->query($query)->$method();
	}
	
	public function getquery2($query=NULL,$where=NULL,$single=FALSE){
		if($where){
			$this->db->where($where);
		}

		if($single == TRUE){
			$method = 'row_array';
		} else {
			$method = 'result_array';
		}

		return $this->db->query($query)->$method();
	}
}